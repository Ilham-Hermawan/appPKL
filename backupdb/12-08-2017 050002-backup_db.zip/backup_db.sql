#
# TABLE STRUCTURE FOR: app_config
#

DROP TABLE IF EXISTS `app_config`;

CREATE TABLE `app_config` (
  `config_key` varchar(255) NOT NULL,
  `config_value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`config_key`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `app_config` (`config_key`, `config_value`) VALUES ('app_description', 'Viland Property System');
INSERT INTO `app_config` (`config_key`, `config_value`) VALUES ('app_logo', 'logo.png');
INSERT INTO `app_config` (`config_key`, `config_value`) VALUES ('app_name', 'Viland Property System');
INSERT INTO `app_config` (`config_key`, `config_value`) VALUES ('app_version', '3.1.5');
INSERT INTO `app_config` (`config_key`, `config_value`) VALUES ('company_address', 'Komplek Terminal Induk No.3\r\n<br/>\r\nJalan Alianyang - Kota Singkawang (79116)');
INSERT INTO `app_config` (`config_key`, `config_value`) VALUES ('company_email', 'vilandproperty@gmail.com');
INSERT INTO `app_config` (`config_key`, `config_value`) VALUES ('company_name', 'V I L A N D');
INSERT INTO `app_config` (`config_key`, `config_value`) VALUES ('company_owner', 'CHALID RAZALVI');
INSERT INTO `app_config` (`config_key`, `config_value`) VALUES ('company_phone', '(0562) 4644314');
INSERT INTO `app_config` (`config_key`, `config_value`) VALUES ('last_backup', '0000-00-00 00:00:00');
INSERT INTO `app_config` (`config_key`, `config_value`) VALUES ('site_favicon', 'favicon.ico');
INSERT INTO `app_config` (`config_key`, `config_value`) VALUES ('site_timezone', 'Asia/Jakarta');
INSERT INTO `app_config` (`config_key`, `config_value`) VALUES ('site_title', 'Viland Property System');
INSERT INTO `app_config` (`config_key`, `config_value`) VALUES ('company_website', 'www.vilandproperty.com');


#
# TABLE STRUCTURE FOR: detil_akad
#

DROP TABLE IF EXISTS `detil_akad`;

CREATE TABLE `detil_akad` (
  `ad_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `akad_id` bigint(20) DEFAULT NULL,
  `booking_id` bigint(20) DEFAULT NULL,
  `ad_status` enum('n','y') DEFAULT 'n',
  PRIMARY KEY (`ad_id`),
  KEY `dakad_bookingid_fk` (`booking_id`),
  KEY `dakad_akadid_fk` (`akad_id`),
  CONSTRAINT `dakad_akadid_fk` FOREIGN KEY (`akad_id`) REFERENCES `tb_akad` (`akad_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `dakad_bookingid_fk` FOREIGN KEY (`booking_id`) REFERENCES `tb_booking` (`booking_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `detil_akad` (`ad_id`, `akad_id`, `booking_id`, `ad_status`) VALUES ('1', '1', '20', 'y');
INSERT INTO `detil_akad` (`ad_id`, `akad_id`, `booking_id`, `ad_status`) VALUES ('2', '2', '33', 'y');
INSERT INTO `detil_akad` (`ad_id`, `akad_id`, `booking_id`, `ad_status`) VALUES ('3', '3', '26', 'y');
INSERT INTO `detil_akad` (`ad_id`, `akad_id`, `booking_id`, `ad_status`) VALUES ('4', '4', '27', 'y');
INSERT INTO `detil_akad` (`ad_id`, `akad_id`, `booking_id`, `ad_status`) VALUES ('5', '5', '36', 'y');
INSERT INTO `detil_akad` (`ad_id`, `akad_id`, `booking_id`, `ad_status`) VALUES ('6', '6', '43', 'y');
INSERT INTO `detil_akad` (`ad_id`, `akad_id`, `booking_id`, `ad_status`) VALUES ('7', '7', '34', 'y');


#
# TABLE STRUCTURE FOR: detil_kelengkapan
#

DROP TABLE IF EXISTS `detil_kelengkapan`;

CREATE TABLE `detil_kelengkapan` (
  `kelengkapan_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pelanggan_id` bigint(20) DEFAULT NULL,
  `booking_id` bigint(20) DEFAULT NULL,
  `kelengkapan` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`kelengkapan_id`),
  KEY `dkelengkapan_bookingid_fk` (`booking_id`),
  KEY `dkelengkapan_pelangganid_fk` (`pelanggan_id`),
  CONSTRAINT `dkelengkapan_bookingid_fk` FOREIGN KEY (`booking_id`) REFERENCES `tb_booking` (`booking_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `dkelengkapan_pelangganid_fk` FOREIGN KEY (`pelanggan_id`) REFERENCES `tb_pelanggan` (`pelanggan_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=172 DEFAULT CHARSET=latin1;

INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('1', '30', '20', 'KTP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('2', '30', '20', 'KARTU KELUARGA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('3', '30', '20', 'NPWP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('4', '30', '20', 'SURAT KETERANGAN USAHA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('5', '30', '20', 'BUKU TABUNGAN BANK BTN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('6', '30', '20', 'FROM BTN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('7', '30', '20', 'FORM A - E');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('8', '30', '20', 'BON PENJUALAN 3 BULAN TERAKHIR');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('9', '43', '33', 'KTP SUAMI/ISTRI');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('10', '43', '33', 'KARTU KELUARGA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('11', '43', '33', 'NPWP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('12', '43', '33', 'SURAT NIKAH');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('13', '43', '33', 'SURAT KETERANGAN KERJA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('14', '43', '33', 'SLIP GAJI 3 BULAN TERAKHIR');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('15', '43', '33', 'BUKU TABUNGAN BANK BTN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('16', '43', '33', 'FOTO TEMPAT KERJA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('17', '43', '33', 'FORM BTN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('18', '43', '33', 'FORM A - E');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('19', '32', '22', 'KTP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('20', '32', '22', 'KARTU KELUARGA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('21', '32', '22', 'NPWP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('22', '32', '22', 'SURAT KETERNGAN KERJA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('23', '32', '22', 'SLIP GAJI 3 BULAN TERAKHIR');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('24', '32', '22', 'BUKU TABUNGAN BANK BTN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('25', '32', '22', 'FORM A - E');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('26', '32', '22', 'FORM BTN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('27', '33', '23', 'KTP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('28', '33', '23', 'KARTU KELUARGA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('29', '33', '23', 'NPWP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('30', '33', '23', 'SURATKETERANGAN KERJA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('31', '33', '23', 'SLIP GAJI 3 BULAN TERAKHIR');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('32', '33', '23', 'FORM BTN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('33', '33', '23', 'FORM A - E');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('34', '33', '23', 'TABUNGAN BANK BTN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('35', '36', '26', 'KTP SUAMI/ISTRI');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('36', '36', '26', 'KARTU KELUARGA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('37', '36', '26', 'NPWP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('38', '36', '26', 'SURAT NIKAH');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('39', '36', '26', 'SURAT KETERANGAN KERJA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('40', '36', '26', 'SLIP GAJI 3 BULAN TERAKHIR');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('41', '36', '26', 'BUKU TABUNGAN BANK BTN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('42', '36', '26', 'FORM BTN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('43', '36', '26', 'FORM A - E');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('44', '37', '27', 'KTP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('45', '37', '27', 'KARTU KELUARGA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('46', '37', '27', 'NPWP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('47', '37', '27', 'SURAT KETERANGAN KERJA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('48', '37', '27', 'SLIP GAJI 3 BULAN TERAKHIR');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('49', '37', '27', 'FORM BTN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('50', '37', '27', 'FORM A - E');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('51', '37', '27', 'BUKU TABUNGAN BANK BTN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('52', '46', '36', 'KTP SUAMI/ISTRI');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('53', '46', '36', 'KARTU KELUARGA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('54', '46', '36', 'BUKU NIKAH');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('55', '46', '36', 'NPWP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('56', '46', '36', 'SURAT KETERANGAN USAHA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('57', '46', '36', 'BON PENJUALAN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('58', '46', '36', 'FORM BTN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('59', '46', '36', 'FORM A - E');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('60', '46', '36', 'BUKU TABUNGAN BTN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('61', '44', '34', 'KTP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('62', '44', '34', 'KARTU KELUARGA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('63', '44', '34', 'SURAT KETERANGAN KERJA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('64', '44', '34', 'SLIP GAJI 3 BULAN TERAKHIR');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('65', '44', '34', 'BUKU TABUNGAN BTN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('66', '44', '34', 'NPWP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('67', '44', '34', 'FORM BANK BTN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('68', '44', '34', 'FORM A - E');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('69', '53', '43', 'KTP SUAMI/ISTRI');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('70', '53', '43', 'KARTU KELUARGA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('71', '53', '43', 'SURAT KETERANGAN USAHA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('72', '53', '43', 'BON PENJUALAN 3 BULAN TERAKHIR');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('73', '53', '43', 'NPWP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('74', '53', '43', 'FORM BANK BTN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('75', '53', '43', 'FORM A - E');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('76', '53', '43', 'BUKU TABUNGAN BTN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('77', '29', '19', 'KTP SUAMI/ISTRI');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('78', '29', '19', 'KARTU KELUARGA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('79', '29', '19', 'FC. BUKU NIKAH');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('80', '29', '19', 'NPWP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('81', '29', '19', 'SURAT KETERANGAN KERJA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('82', '29', '19', 'SLIP GAJI 3 BULAN TERAKHIR');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('83', '29', '19', 'BUKU TABUNGAN BANK BTN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('84', '29', '19', 'SBUM');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('85', '4', '2', 'KTP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('86', '4', '2', 'KARTU KELUARGA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('87', '4', '2', 'NPWP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('88', '4', '2', 'SURAT KETERANGAN KERJA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('89', '4', '2', 'SLIP GAJI 3 BULAN TERAKHIR');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('90', '4', '2', 'SURAT PEMOTONGAN GAJI');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('91', '4', '2', 'SBUM');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('92', '4', '2', 'BUKU TABUNGAN BANK BTN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('93', '50', '40', 'KTP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('94', '50', '40', 'KARTU KELUARGA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('95', '50', '40', 'NPWP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('96', '50', '40', 'SURAT KETERANGAN USAHA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('97', '50', '40', 'BON PENJUALAN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('98', '50', '40', 'BUKU TABUNGAN BANK BTN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('99', '50', '40', 'FOTO TEMPAT USAHA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('100', '50', '40', 'DENAH TEMPAT USAHA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('101', '5', '3', 'KTP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('102', '5', '3', 'NPWP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('103', '5', '3', 'KARTU KELUARGA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('104', '5', '3', 'SK TERAKHIR DAN PERTAMA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('105', '5', '3', 'SLIP GAJI 3 BULAN TERAKHIR');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('106', '5', '3', 'SBUM');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('107', '5', '3', 'SURAT PEMOTONGAN GAJI');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('108', '5', '3', 'BUKU TABUNGAN BANK BTN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('109', '6', '4', 'KTP SUAMI/ISTRI');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('110', '6', '4', 'NPWP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('111', '6', '4', 'KARTU KELUARGA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('112', '6', '4', 'BUKU NIKAH');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('113', '6', '4', 'SURAT KETERANGAN KERJA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('114', '6', '4', 'SLIP GAJI 3 BULAN TERAKHIR');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('115', '6', '4', 'SBUM');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('116', '6', '4', 'BUKU TABUNGAN BANK BTN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('117', '21', '11', 'KTP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('118', '21', '11', 'KARTU KELUARGA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('119', '21', '11', 'NPWP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('120', '21', '11', 'SURAT KETERANGAN USAHA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('121', '21', '11', 'BON PENJUALAN 3 BULAN TERAKHIR');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('122', '21', '11', 'FOTO TEMPAT USAHA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('123', '21', '11', 'DENAH TEMPAT USAHA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('124', '21', '11', 'BUKU TABUNGAN BANK BTN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('125', '15', '5', 'KTP SUAMI/ISTERI');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('126', '15', '5', 'KARTU KELUARGA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('127', '15', '5', 'NPWP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('128', '15', '5', 'BUKU NIKAH');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('129', '15', '5', 'SURAT KETERANGAN KERJA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('130', '15', '5', 'SLIP GAJI 3 BULAN TERAKHIR');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('131', '15', '5', 'BUKU TABUNGAN BANK BTN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('132', '15', '5', 'SBUM');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('133', '16', '6', 'KTP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('134', '16', '6', 'KARTU KELUARGA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('135', '16', '6', 'NPWP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('136', '16', '6', 'SURAT KETERANGAN USAHA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('137', '16', '6', 'BON PENJUALAN 3 BULAN TERAKHIR');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('138', '16', '6', 'BUKU TABUNGAN BANK BTN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('139', '16', '6', 'FOTO TEMPAT USAHA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('140', '16', '6', 'DENAH TEMPAT USAHA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('141', '24', '14', 'KTP SUAMI/ISTERI');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('142', '24', '14', 'KARTU KELUARGA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('143', '24', '14', 'NPWP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('144', '24', '14', 'BUKU NIKAH');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('145', '24', '14', 'SURAT KETERANGAN KERJA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('146', '24', '14', 'SLIP GAJI 3 BULAN TERAKHIR');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('147', '24', '14', 'BUKU TABUNGAN BANK BTN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('148', '24', '14', 'SBUM');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('149', '22', '12', 'KTP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('150', '22', '12', 'KARTU KELUARGA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('151', '22', '12', 'NPWP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('152', '22', '12', 'SURAT KETERANGAN USAHA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('153', '22', '12', 'BON PENJUALAN 3 BULAN TERAKHIR');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('154', '22', '12', 'BUKU TABUNGAN BANK BTN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('155', '22', '12', 'FOTO TEMPAT USAHA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('156', '22', '12', 'DENAH TEMPAT USAHA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('157', '42', '32', 'KTP SUAMI/ISTERI');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('158', '42', '32', 'NPWP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('159', '42', '32', 'KARTU KELUARGA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('160', '42', '32', 'BUKU NIKAH');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('161', '42', '32', 'SURAT KETERANGAN KERJA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('162', '42', '32', 'SLIP GAJI 3 BULAN TERAKHIR');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('163', '42', '32', 'SBUM');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('164', '42', '32', 'BUKU TABUNGAN BANK BTN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('165', '18', '8', 'KTP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('166', '18', '8', 'KARTU KELUARGA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('167', '18', '8', 'NPWP');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('168', '18', '8', 'SURAT KETERANGAN KERJA');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('169', '18', '8', 'SLIP GAJI 3 BULAN TERAKHIR');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('170', '18', '8', 'BUKU TABUNGAN BTN');
INSERT INTO `detil_kelengkapan` (`kelengkapan_id`, `pelanggan_id`, `booking_id`, `kelengkapan`) VALUES ('171', '18', '8', 'SBUM');


#
# TABLE STRUCTURE FOR: detil_lpa
#

DROP TABLE IF EXISTS `detil_lpa`;

CREATE TABLE `detil_lpa` (
  `dlpa_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `lpa_id` bigint(20) DEFAULT NULL,
  `booking_id` bigint(20) DEFAULT NULL,
  `dlpa_status` enum('n','y') DEFAULT NULL,
  PRIMARY KEY (`dlpa_id`),
  KEY `dlpa_lpaid_fk` (`lpa_id`),
  KEY `dlpa_bookingid_fk` (`booking_id`),
  CONSTRAINT `dlpa_bookingid_fk` FOREIGN KEY (`booking_id`) REFERENCES `tb_booking` (`booking_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `dlpa_lpaid_fk` FOREIGN KEY (`lpa_id`) REFERENCES `tb_lpa` (`lpa_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `detil_lpa` (`dlpa_id`, `lpa_id`, `booking_id`, `dlpa_status`) VALUES ('1', '1', '20', 'y');
INSERT INTO `detil_lpa` (`dlpa_id`, `lpa_id`, `booking_id`, `dlpa_status`) VALUES ('2', '2', '33', 'y');
INSERT INTO `detil_lpa` (`dlpa_id`, `lpa_id`, `booking_id`, `dlpa_status`) VALUES ('3', '3', '23', 'y');
INSERT INTO `detil_lpa` (`dlpa_id`, `lpa_id`, `booking_id`, `dlpa_status`) VALUES ('4', '4', '26', 'y');
INSERT INTO `detil_lpa` (`dlpa_id`, `lpa_id`, `booking_id`, `dlpa_status`) VALUES ('5', '5', '27', 'y');
INSERT INTO `detil_lpa` (`dlpa_id`, `lpa_id`, `booking_id`, `dlpa_status`) VALUES ('6', '6', '36', 'y');
INSERT INTO `detil_lpa` (`dlpa_id`, `lpa_id`, `booking_id`, `dlpa_status`) VALUES ('7', '7', '43', 'y');
INSERT INTO `detil_lpa` (`dlpa_id`, `lpa_id`, `booking_id`, `dlpa_status`) VALUES ('8', '8', '34', 'y');


#
# TABLE STRUCTURE FOR: detil_wawancara
#

DROP TABLE IF EXISTS `detil_wawancara`;

CREATE TABLE `detil_wawancara` (
  `dw_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `wawancara_id` bigint(20) DEFAULT NULL,
  `booking_id` bigint(20) DEFAULT NULL,
  `dw_status` enum('n','y') DEFAULT 'n',
  PRIMARY KEY (`dw_id`),
  KEY `dwawancara_bookingid_fk` (`booking_id`),
  KEY `dwawancara_wawancaraid_fk` (`wawancara_id`),
  CONSTRAINT `dwawancara_bookingid_fk` FOREIGN KEY (`booking_id`) REFERENCES `tb_booking` (`booking_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `dwawancara_wawancaraid_fk` FOREIGN KEY (`wawancara_id`) REFERENCES `tb_wawancara` (`wawancara_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

INSERT INTO `detil_wawancara` (`dw_id`, `wawancara_id`, `booking_id`, `dw_status`) VALUES ('1', '1', '20', 'y');
INSERT INTO `detil_wawancara` (`dw_id`, `wawancara_id`, `booking_id`, `dw_status`) VALUES ('2', '1', '33', 'y');
INSERT INTO `detil_wawancara` (`dw_id`, `wawancara_id`, `booking_id`, `dw_status`) VALUES ('3', '1', '22', 'n');
INSERT INTO `detil_wawancara` (`dw_id`, `wawancara_id`, `booking_id`, `dw_status`) VALUES ('4', '1', '23', 'y');
INSERT INTO `detil_wawancara` (`dw_id`, `wawancara_id`, `booking_id`, `dw_status`) VALUES ('5', '1', '26', 'y');
INSERT INTO `detil_wawancara` (`dw_id`, `wawancara_id`, `booking_id`, `dw_status`) VALUES ('6', '1', '27', 'y');
INSERT INTO `detil_wawancara` (`dw_id`, `wawancara_id`, `booking_id`, `dw_status`) VALUES ('9', '1', '34', 'y');
INSERT INTO `detil_wawancara` (`dw_id`, `wawancara_id`, `booking_id`, `dw_status`) VALUES ('10', '2', '36', 'y');
INSERT INTO `detil_wawancara` (`dw_id`, `wawancara_id`, `booking_id`, `dw_status`) VALUES ('11', '3', '43', 'y');
INSERT INTO `detil_wawancara` (`dw_id`, `wawancara_id`, `booking_id`, `dw_status`) VALUES ('12', '4', '19', 'y');
INSERT INTO `detil_wawancara` (`dw_id`, `wawancara_id`, `booking_id`, `dw_status`) VALUES ('13', '5', '2', 'y');
INSERT INTO `detil_wawancara` (`dw_id`, `wawancara_id`, `booking_id`, `dw_status`) VALUES ('14', '6', '40', 'y');
INSERT INTO `detil_wawancara` (`dw_id`, `wawancara_id`, `booking_id`, `dw_status`) VALUES ('15', '7', '3', 'y');
INSERT INTO `detil_wawancara` (`dw_id`, `wawancara_id`, `booking_id`, `dw_status`) VALUES ('16', '8', '4', 'y');
INSERT INTO `detil_wawancara` (`dw_id`, `wawancara_id`, `booking_id`, `dw_status`) VALUES ('17', '9', '11', 'y');
INSERT INTO `detil_wawancara` (`dw_id`, `wawancara_id`, `booking_id`, `dw_status`) VALUES ('18', '10', '5', 'y');
INSERT INTO `detil_wawancara` (`dw_id`, `wawancara_id`, `booking_id`, `dw_status`) VALUES ('19', '11', '6', 'y');
INSERT INTO `detil_wawancara` (`dw_id`, `wawancara_id`, `booking_id`, `dw_status`) VALUES ('20', '12', '14', 'y');
INSERT INTO `detil_wawancara` (`dw_id`, `wawancara_id`, `booking_id`, `dw_status`) VALUES ('21', '13', '12', 'y');
INSERT INTO `detil_wawancara` (`dw_id`, `wawancara_id`, `booking_id`, `dw_status`) VALUES ('22', '14', '32', 'y');
INSERT INTO `detil_wawancara` (`dw_id`, `wawancara_id`, `booking_id`, `dw_status`) VALUES ('23', '15', '8', 'y');


#
# TABLE STRUCTURE FOR: log_umeta
#

DROP TABLE IF EXISTS `log_umeta`;

CREATE TABLE `log_umeta` (
  `umeta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `umeta_lastlogin` datetime DEFAULT NULL,
  `umeta_agent` varchar(255) DEFAULT NULL,
  `umeta_platform` varchar(255) DEFAULT NULL,
  `umeta_version` varchar(255) DEFAULT NULL,
  `umeta_ip` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`umeta_id`)
) ENGINE=MyISAM AUTO_INCREMENT=376 DEFAULT CHARSET=latin1;

INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('1', '1', '2016-10-09 13:03:18', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('2', '1', '2016-10-09 14:14:42', 'Firefox', 'Windows 7', '41.0', '36.82.171.112');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('3', '1', '2016-10-09 14:15:05', 'Firefox', 'Windows 7', '41.0', '36.82.171.112');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('4', '1', '2016-10-09 14:16:58', 'Chrome', 'Android', '46.0.2490.85', '36.82.171.112');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('5', '1', '2016-10-09 18:11:54', 'Chrome', 'Android', '46.0.2490.85', '202.67.35.24');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('6', '1', '2016-10-10 09:48:47', 'Firefox', 'Windows 7', '41.0', '125.164.89.232');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('7', '2', '2016-10-11 12:13:36', 'Safari', 'iOS', '602.1', '114.125.175.230');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('8', '5', '2016-10-11 12:14:32', 'Safari', 'iOS', '602.1', '114.125.175.230');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('9', '3', '2016-10-12 16:51:41', 'Chrome', 'Windows 7', '53.0.2785.143', '36.83.14.205');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('10', '3', '2016-10-12 16:51:42', 'Chrome', 'Windows 7', '53.0.2785.143', '36.83.14.205');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('11', '1', '2016-10-13 14:51:01', 'Firefox', 'Windows 7', '41.0', '180.246.189.180');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('12', '3', '2016-10-13 16:36:30', 'Safari', 'Mac OS X', '537.86.7', '114.125.168.87');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('13', '1', '2016-10-13 16:40:12', 'Firefox', 'Windows 7', '41.0', '180.246.189.180');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('14', '1', '2016-10-14 08:24:33', 'Firefox', 'Windows 7', '40.0', '125.164.89.189');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('15', '1', '2016-10-15 15:27:27', 'Firefox', 'Windows 7', '41.0', '180.246.189.180');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('16', '1', '2016-10-17 17:55:19', 'Firefox', 'Windows 7', '41.0', '180.246.189.180');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('17', '3', '2016-10-19 10:52:58', 'Chrome', 'Windows 7', '52.0.2743.116', '36.85.209.76');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('18', '2', '2016-10-19 10:54:24', 'Chrome', 'Windows 7', '52.0.2743.116', '36.85.209.76');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('19', '3', '2016-10-19 10:58:55', 'Chrome', 'Windows 7', '52.0.2743.116', '36.85.209.76');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('20', '2', '2016-10-19 11:00:57', 'Chrome', 'Windows 7', '52.0.2743.116', '36.85.209.76');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('21', '2', '2016-10-19 11:28:46', 'Safari', 'iOS', '602.1', '114.125.174.183');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('22', '2', '2016-10-19 11:30:00', 'Chrome', 'Windows 7', '53.0.2785.143', '36.85.209.76');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('23', '5', '2016-10-19 11:31:22', 'Chrome', 'Windows 7', '53.0.2785.143', '36.85.209.76');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('24', '2', '2016-10-19 11:32:49', 'Chrome', 'Windows 7', '53.0.2785.143', '36.85.209.76');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('25', '3', '2016-10-19 11:40:34', 'Chrome', 'Windows 7', '53.0.2785.143', '36.85.209.76');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('26', '2', '2016-10-19 11:41:34', 'Chrome', 'Windows 7', '53.0.2785.143', '36.85.209.76');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('27', '2', '2016-10-19 12:04:06', 'Chrome', 'Windows 7', '53.0.2785.143', '36.85.209.76');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('28', '1', '2016-10-19 12:05:27', 'Firefox', 'Windows 7', '41.0', '125.167.197.250');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('29', '1', '2016-10-19 19:13:33', 'Firefox', 'Windows 7', '41.0', '127.0.0.1');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('30', '1', '2016-10-19 20:06:13', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('31', '1', '2016-10-19 20:41:41', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('32', '1', '2016-10-21 18:58:08', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('33', '1', '2016-11-10 10:04:01', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('34', '1', '2016-12-04 15:13:09', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('35', '1', '2016-12-05 23:10:06', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('36', '1', '2016-12-06 18:55:04', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('37', '1', '2016-12-07 13:04:07', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('38', '1', '2016-12-07 21:56:15', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('39', '1', '2016-12-08 02:13:01', 'Safari', 'Mac OS X', '600.5.17', '192.168.1.14');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('40', '1', '2016-12-09 10:14:16', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('41', '1', '2016-12-10 09:25:32', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('42', '1', '2016-12-10 12:35:04', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('43', '2', '2016-12-11 14:57:24', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('44', '1', '2016-12-15 21:31:35', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('45', '1', '2016-12-19 10:52:54', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('46', '1', '2016-12-21 16:15:18', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('47', '1', '2016-12-21 17:26:19', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('48', '1', '2016-12-25 22:47:24', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('49', '1', '2016-12-26 00:55:24', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('50', '1', '2016-12-26 22:38:24', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('51', '1', '2017-01-07 11:00:01', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('52', '1', '2017-01-12 08:10:49', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('53', '1', '2017-01-13 21:01:27', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('54', '1', '2017-01-14 03:52:34', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('55', '1', '2017-01-14 06:19:05', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('56', '1', '2017-01-14 12:26:41', 'Chrome', 'Mac OS X', '55.0.2883.95', '192.168.1.4');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('57', '1', '2017-01-14 13:11:18', 'Firefox', 'Windows 8.1', '49.0', '192.168.1.20');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('58', '1', '2017-01-17 15:39:00', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('59', '1', '2017-01-19 07:23:40', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('60', '1', '2017-01-19 10:00:58', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('61', '1', '2017-01-23 10:16:28', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('62', '1', '2017-01-23 19:14:52', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('63', '1', '2017-01-24 16:19:45', 'Firefox', 'Windows 7', '41.0', '127.0.0.1');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('64', '1', '2017-01-24 16:56:16', 'Firefox', 'Windows 7', '41.0', '127.0.0.1');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('65', '1', '2017-01-25 10:52:18', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('66', '1', '2017-01-25 20:43:13', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('67', '1', '2017-01-26 14:05:35', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('68', '2', '2017-01-26 14:51:37', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('69', '3', '2017-01-26 14:51:56', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('70', '1', '2017-01-26 21:52:07', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('71', '1', '2017-01-28 21:25:00', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('72', '1', '2017-01-28 22:15:11', 'Chrome', 'Mac OS X', '55.0.2883.95', '192.168.1.4');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('73', '1', '2017-01-28 23:05:53', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('74', '1', '2017-01-29 05:41:41', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('75', '3', '2017-01-29 05:42:02', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('76', '1', '2017-01-29 05:42:17', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('77', '3', '2017-01-29 13:36:21', 'Safari', 'Mac OS X', '601.7.7', '192.168.1.7');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('78', '1', '2017-01-29 14:08:10', 'Chrome', 'Windows 7', '55.0.2883.87', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('79', '3', '2017-01-29 14:24:50', 'Chrome', 'Mac OS X', '56.0.2924.76', '192.168.1.7');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('80', '1', '2017-01-29 14:50:33', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('81', '1', '2017-02-01 12:41:41', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('82', '1', '2017-02-18 00:15:52', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('83', '1', '2017-02-18 03:55:09', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('84', '1', '2017-02-28 22:36:59', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('85', '1', '2017-03-01 10:23:08', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('86', '1', '2017-03-01 10:25:20', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('87', '1', '2017-03-01 11:21:28', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('88', '1', '2017-03-01 20:04:25', 'Firefox', 'Windows 7', '41.0', 'localhost');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('89', '1', '2017-03-02 00:38:15', 'Firefox', 'Windows 8.1', '51.0', '192.168.1.5');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('90', '1', '2017-03-02 17:26:16', 'Firefox', 'Windows 7', '41.0', '36.74.252.45');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('91', '1', '2017-03-02 17:28:46', 'Firefox', 'Windows 7', '41.0', '36.74.252.45');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('92', '3', '2017-03-02 18:43:58', 'Safari', 'Mac OS X', '537.86.7', '114.120.234.71');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('93', '3', '2017-03-02 20:26:15', 'Chrome', 'Android', '50.0.2661.89', '120.188.93.65');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('94', '3', '2017-03-04 12:11:38', 'Safari', 'iOS', '602.1', '114.120.236.159');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('95', '2', '2017-03-04 12:12:01', 'Safari', 'iOS', '602.1', '114.125.171.187');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('96', '3', '2017-03-04 12:15:49', 'Chrome', 'Android', '30.0.0.0', '36.85.113.153');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('97', '3', '2017-03-05 18:21:51', 'Chrome', 'Mac OS X', '56.0.2924.87', '110.139.102.45');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('98', '1', '2017-03-06 00:16:07', 'Firefox', 'Windows 7', '41.0', '180.246.153.166');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('99', '2', '2017-03-06 08:43:13', 'Chrome', 'Windows 10', '48.0.2564.82', '110.139.102.45');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('100', '2', '2017-03-06 08:47:50', 'Chrome', 'Windows 10', '48.0.2564.82', '110.139.102.45');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('101', '5', '2017-03-06 09:13:21', 'Chrome', 'Windows 7', '56.0.2924.87', '110.139.102.45');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('102', '3', '2017-03-06 09:26:01', 'Chrome', 'Windows 10', '48.0.2564.82', '110.139.102.45');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('103', '2', '2017-03-06 09:29:01', 'Chrome', 'Windows 10', '48.0.2564.82', '110.139.102.45');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('104', '3', '2017-03-06 09:29:47', 'Chrome', 'Windows 10', '48.0.2564.82', '110.139.102.45');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('105', '2', '2017-03-06 09:46:55', 'Chrome', 'Windows 10', '48.0.2564.82', '110.139.102.45');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('106', '1', '2017-03-06 10:41:59', 'Firefox', 'Windows 7', '41.0', '36.74.252.45');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('107', '5', '2017-03-06 11:13:01', 'Chrome', 'Windows 7', '56.0.2924.87', '110.139.102.45');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('108', '3', '2017-03-06 11:26:18', 'Chrome', 'Windows 7', '56.0.2924.87', '110.139.102.45');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('109', '5', '2017-03-06 11:41:33', 'Chrome', 'Windows 7', '56.0.2924.87', '110.139.102.45');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('110', '2', '2017-03-06 13:20:12', 'Chrome', 'Windows 10', '56.0.2924.87', '110.139.102.45');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('111', '2', '2017-03-06 16:02:57', 'Chrome', 'Windows 10', '56.0.2924.87', '110.139.102.45');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('112', '1', '2017-03-06 18:38:01', 'Firefox', 'Windows 7', '41.0', '36.74.252.45');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('113', '2', '2017-03-07 09:58:35', 'Chrome', 'Windows 10', '56.0.2924.87', '110.139.102.45');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('114', '5', '2017-03-07 10:07:36', 'Chrome', 'Windows 7', '56.0.2924.87', '114.120.237.92');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('115', '1', '2017-03-07 11:25:24', 'Firefox', 'Windows 7', '41.0', '125.161.20.78');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('116', '1', '2017-03-07 14:27:00', 'Firefox', 'Windows 7', '41.0', '222.124.84.32');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('117', '2', '2017-03-07 16:18:19', 'Chrome', 'Windows 10', '56.0.2924.87', '110.139.102.45');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('118', '1', '2017-03-07 16:38:26', 'Firefox', 'Windows 7', '41.0', '36.74.251.53');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('119', '1', '2017-03-07 17:46:56', 'Opera', 'Android', '12.16', '107.167.103.236');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('120', '1', '2017-03-07 17:50:22', 'Chrome', 'Android', '56.0.2924.87', '36.74.251.53');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('121', '1', '2017-03-08 04:48:28', 'Firefox', 'Windows 7', '41.0', '180.246.154.225');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('122', '5', '2017-03-08 09:29:09', 'Chrome', 'Windows 7', '56.0.2924.87', '110.139.102.45');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('123', '2', '2017-03-08 09:36:04', 'Chrome', 'Windows 10', '56.0.2924.87', '110.139.102.45');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('124', '2', '2017-03-08 10:06:48', 'Chrome', 'Windows 7', '56.0.2924.87', '110.139.102.45');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('125', '1', '2017-03-08 10:36:55', 'Firefox', 'Windows 7', '41.0', '36.74.251.53');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('126', '2', '2017-03-08 10:45:47', 'Chrome', 'Windows 10', '56.0.2924.87', '110.139.104.208');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('127', '2', '2017-03-09 13:31:08', 'Chrome', 'Windows 10', '56.0.2924.87', '61.94.49.132');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('128', '5', '2017-03-09 13:59:22', 'Chrome', 'Windows 7', '56.0.2924.87', '61.94.49.132');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('129', '5', '2017-03-09 14:27:16', 'Chrome', 'Windows 7', '56.0.2924.87', '61.94.49.132');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('130', '5', '2017-03-10 09:48:47', 'Chrome', 'Windows 7', '56.0.2924.87', '61.94.49.132');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('131', '5', '2017-03-10 11:26:03', 'Chrome', 'Windows 7', '56.0.2924.87', '110.139.107.48');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('132', '3', '2017-03-10 13:36:34', 'Chrome', 'Mac OS X', '56.0.2924.87', '36.85.215.134');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('133', '5', '2017-03-11 09:14:22', 'Chrome', 'Windows 7', '56.0.2924.87', '36.85.136.33');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('134', '2', '2017-03-11 09:14:31', 'Chrome', 'Windows 10', '56.0.2924.87', '36.85.136.33');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('135', '1', '2017-03-11 11:40:24', 'Firefox', 'Windows 7', '41.0', '180.248.180.222');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('136', '2', '2017-03-11 11:56:03', 'Firefox', 'Windows 7', '41.0', '180.248.180.222');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('137', '5', '2017-03-11 11:57:10', 'Firefox', 'Windows 7', '41.0', '180.248.180.222');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('138', '5', '2017-03-13 10:07:02', 'Chrome', 'Windows 7', '56.0.2924.87', '36.85.118.24');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('139', '2', '2017-03-13 10:14:54', 'Chrome', 'Windows 10', '56.0.2924.87', '36.85.118.24');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('140', '5', '2017-03-13 14:12:01', 'Chrome', 'Windows 7', '56.0.2924.87', '36.85.118.24');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('141', '1', '2017-03-13 14:24:21', 'Firefox', 'Windows 7', '41.0', '61.94.94.248');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('142', '3', '2017-03-13 14:55:51', 'Chrome', 'Mac OS X', '56.0.2924.87', '36.85.118.24');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('143', '1', '2017-03-13 14:58:03', 'Firefox', 'Windows 7', '41.0', '61.94.94.248');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('144', '5', '2017-03-13 16:55:40', 'Chrome', 'Mac OS X', '56.0.2924.87', '36.85.118.24');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('145', '3', '2017-03-13 17:52:54', 'Chrome', 'Mac OS X', '56.0.2924.87', '36.85.118.24');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('146', '2', '2017-03-14 00:17:14', 'Safari', 'Mac OS X', '602.4.8', '180.252.184.47');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('147', '5', '2017-03-14 09:56:46', 'Chrome', 'Windows 7', '56.0.2924.87', '36.85.118.24');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('148', '3', '2017-03-14 10:16:23', 'Chrome', 'Windows 7', '56.0.2924.87', '36.85.118.24');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('149', '3', '2017-03-14 11:55:14', 'Chrome', 'Mac OS X', '56.0.2924.87', '36.85.118.24');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('150', '5', '2017-03-15 10:45:00', 'Chrome', 'Windows 7', '56.0.2924.87', '36.85.118.24');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('151', '3', '2017-03-15 10:48:18', 'Chrome', 'Windows 7', '56.0.2924.87', '36.85.118.24');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('152', '2', '2017-03-15 10:54:52', 'Chrome', 'Windows 10', '56.0.2924.87', '36.85.118.24');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('153', '5', '2017-03-15 10:56:11', 'Chrome', 'Windows 7', '56.0.2924.87', '36.85.118.24');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('154', '1', '2017-03-15 12:50:40', 'Firefox', 'Windows 7', '41.0', '36.85.140.73');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('155', '3', '2017-03-15 21:18:33', 'Safari', 'iOS', '602.1', '114.120.238.168');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('156', '1', '2017-03-16 09:03:36', 'Firefox', 'Windows 7', '41.0', '180.246.188.121');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('157', '2', '2017-03-16 10:18:25', 'Chrome', 'Windows 10', '56.0.2924.87', '36.85.118.24');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('158', '5', '2017-03-16 15:07:17', 'Chrome', 'Windows 7', '56.0.2924.87', '36.85.118.24');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('159', '1', '2017-03-16 18:17:39', 'Firefox', 'Windows 7', '41.0', '36.85.140.73');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('160', '3', '2017-03-17 10:05:45', 'Safari', 'iOS', '602.1', '114.120.234.4');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('161', '5', '2017-03-17 10:15:15', 'Chrome', 'Windows 7', '56.0.2924.87', '36.85.118.24');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('162', '3', '2017-03-17 11:41:43', 'Chrome', 'Mac OS X', '56.0.2924.87', '36.85.214.36');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('163', '2', '2017-03-17 11:55:53', 'Chrome', 'Windows 10', '56.0.2924.87', '36.85.214.36');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('164', '5', '2017-03-17 13:24:27', 'Chrome', 'Windows 7', '56.0.2924.87', '180.248.164.231');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('165', '3', '2017-03-17 15:36:07', 'Chrome', 'Mac OS X', '56.0.2924.87', '180.248.164.231');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('166', '3', '2017-03-17 16:38:04', 'Chrome', 'Mac OS X', '56.0.2924.87', '180.248.164.231');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('167', '3', '2017-03-17 17:58:46', 'Chrome', 'Mac OS X', '56.0.2924.87', '180.248.164.231');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('168', '5', '2017-03-18 09:20:29', 'Chrome', 'Windows 7', '56.0.2924.87', '180.248.164.231');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('169', '3', '2017-03-18 09:23:09', 'Chrome', 'Mac OS X', '56.0.2924.87', '180.248.164.231');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('170', '1', '2017-03-18 09:57:19', 'Firefox', 'Windows 7', '41.0', '36.85.140.73');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('171', '3', '2017-03-18 13:06:32', 'Safari', 'iOS', '602.1', '180.248.164.231');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('172', '3', '2017-03-20 09:44:29', 'Chrome', 'Mac OS X', '56.0.2924.87', '36.85.119.53');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('173', '2', '2017-03-20 15:05:39', 'Chrome', 'Windows 10', '56.0.2924.87', '36.85.212.104');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('174', '5', '2017-03-22 09:17:33', 'Chrome', 'Windows 7', '56.0.2924.87', '110.136.69.193');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('175', '3', '2017-03-22 11:23:22', 'Chrome', 'Mac OS X', '56.0.2924.87', '110.136.69.193');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('176', '3', '2017-03-22 11:23:45', 'Chrome', 'Mac OS X', '56.0.2924.87', '110.136.69.193');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('177', '3', '2017-03-22 13:52:10', 'Chrome', 'Mac OS X', '56.0.2924.87', '110.136.69.193');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('178', '3', '2017-03-23 14:24:16', 'Chrome', 'Mac OS X', '56.0.2924.87', '180.246.154.167');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('179', '5', '2017-03-24 10:20:21', 'Chrome', 'Windows 7', '56.0.2924.87', '180.246.189.62');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('180', '3', '2017-03-25 09:31:23', 'Chrome', 'Mac OS X', '56.0.2924.87', '180.246.189.62');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('181', '5', '2017-03-25 10:58:07', 'Chrome', 'Windows 7', '56.0.2924.87', '180.246.189.62');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('182', '1', '2017-03-26 13:56:18', 'Firefox', 'Windows 7', '41.0', '36.84.64.77');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('183', '5', '2017-03-29 09:42:46', 'Chrome', 'Windows 7', '56.0.2924.87', '180.246.189.62');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('184', '1', '2017-03-29 10:30:52', 'Firefox', 'Windows 7', '40.0', '36.85.209.245');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('185', '3', '2017-03-31 09:43:10', 'Safari', 'Mac OS X', '537.86.7', '180.246.189.62');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('186', '5', '2017-03-31 11:06:36', 'Chrome', 'Windows 7', '56.0.2924.87', '125.161.21.218');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('187', '5', '2017-03-31 11:06:36', 'Chrome', 'Windows 7', '56.0.2924.87', '125.161.21.218');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('188', '1', '2017-04-02 18:03:48', 'Firefox', 'Windows 7', '41.0', '36.84.64.178');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('189', '1', '2017-04-02 18:23:30', 'Firefox', 'Windows 7', '41.0', '36.84.64.178');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('190', '1', '2017-04-03 09:54:16', 'Firefox', 'Windows 7', '49.0', '180.248.235.122');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('191', '2', '2017-04-03 09:54:26', 'Firefox', 'Windows 7', '49.0', '180.248.235.122');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('192', '5', '2017-04-03 09:54:37', 'Firefox', 'Windows 7', '49.0', '180.248.235.122');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('193', '1', '2017-04-03 10:22:14', 'Firefox', 'Windows 7', '49.0', '180.248.235.122');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('194', '5', '2017-04-03 10:38:15', 'Chrome', 'Windows 7', '56.0.2924.87', '125.160.80.35');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('195', '3', '2017-04-03 10:43:11', 'Chrome', 'Windows 7', '56.0.2924.87', '125.160.80.35');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('196', '5', '2017-04-03 10:45:42', 'Chrome', 'Windows 7', '56.0.2924.87', '125.160.80.35');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('197', '5', '2017-04-03 14:02:25', 'Chrome', 'Windows 7', '56.0.2924.87', '180.248.165.124');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('198', '3', '2017-04-03 14:15:01', 'Chrome', 'Windows 7', '56.0.2924.87', '180.248.165.124');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('199', '5', '2017-04-03 14:29:53', 'Chrome', 'Windows 7', '56.0.2924.87', '180.248.165.124');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('200', '1', '2017-04-04 09:01:04', 'Firefox', 'Windows 7', '41.0', '125.167.197.146');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('201', '1', '2017-04-04 09:35:36', 'Chrome', 'Android', '56.0.2924.87', '125.167.197.146');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('202', '1', '2017-04-04 13:56:32', 'Firefox', 'Windows 7', '49.0', '125.167.197.146');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('203', '1', '2017-04-05 21:39:57', 'Firefox', 'Windows 7', '41.0', '125.164.90.193');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('204', '5', '2017-04-07 10:56:53', 'Chrome', 'Windows 7', '56.0.2924.87', '36.74.254.209');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('205', '5', '2017-04-07 11:07:07', 'Chrome', 'Windows 7', '57.0.2987.133', '36.74.254.209');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('206', '1', '2017-04-07 13:54:12', 'Firefox', 'Windows 7', '49.0', '125.160.95.26');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('207', '5', '2017-04-08 11:24:45', 'Chrome', 'Windows 10', '57.0.2987.133', '36.74.254.209');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('208', '1', '2017-04-08 14:05:06', 'Firefox', 'Windows 7', '49.0', '180.248.187.182');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('209', '5', '2017-04-11 10:37:17', 'Chrome', 'Windows 10', '57.0.2987.133', '36.74.252.159');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('210', '1', '2017-04-11 20:31:04', 'Firefox', 'Windows 7', '41.0', '61.94.183.74');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('211', '5', '2017-04-13 10:05:23', 'Chrome', 'Windows 7', '57.0.2987.133', '125.160.92.156');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('212', '5', '2017-04-19 13:13:04', 'Chrome', 'Windows 7', '57.0.2987.133', '125.167.197.86');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('213', '5', '2017-04-21 11:06:33', 'Chrome', 'Windows 7', '57.0.2987.133', '180.248.186.160');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('214', '2', '2017-04-21 11:10:06', 'Chrome', 'Windows 10', '57.0.2987.133', '180.248.186.160');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('215', '5', '2017-04-21 11:19:25', 'Chrome', 'Windows 7', '57.0.2987.133', '180.248.186.160');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('216', '5', '2017-04-21 13:39:33', 'Chrome', 'Windows 7', '57.0.2987.133', '180.248.186.160');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('217', '5', '2017-04-25 09:39:05', 'Chrome', 'Windows 7', '57.0.2987.133', '180.248.186.160');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('218', '3', '2017-04-25 13:47:26', 'Chrome', 'Mac OS X', '57.0.2987.133', '180.248.186.160');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('219', '3', '2017-04-28 10:14:37', 'Chrome', 'Mac OS X', '57.0.2987.133', '180.248.232.185');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('220', '5', '2017-04-29 09:17:36', 'Chrome', 'Windows 7', '57.0.2987.133', '36.74.255.17');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('221', '5', '2017-04-29 09:36:07', 'Chrome', 'Windows 7', '57.0.2987.133', '36.74.255.17');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('222', '3', '2017-05-01 15:48:39', 'Safari', 'iOS', '602.1', '114.120.234.195');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('223', '1', '2017-05-01 22:34:13', 'Firefox', 'Windows 7', '41.0', '125.160.83.193');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('224', '3', '2017-05-02 09:40:39', 'Chrome', 'Mac OS X', '57.0.2987.133', '114.124.148.240');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('225', '5', '2017-05-03 09:49:45', 'Chrome', 'Windows 7', '57.0.2987.133', '180.249.255.86');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('226', '5', '2017-05-03 09:56:49', 'Chrome', 'Windows 7', '57.0.2987.133', '180.249.255.86');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('227', '5', '2017-05-03 10:00:53', 'Chrome', 'Windows 7', '57.0.2987.133', '180.249.255.86');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('228', '3', '2017-05-03 10:19:32', 'Chrome', 'Windows 7', '57.0.2987.133', '180.249.255.86');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('229', '5', '2017-05-03 10:24:49', 'Chrome', 'Windows 7', '57.0.2987.133', '180.249.255.86');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('230', '3', '2017-05-04 09:25:27', 'Chrome', 'Mac OS X', '57.0.2987.133', '114.120.234.18');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('231', '5', '2017-05-04 15:55:17', 'Chrome', 'Windows 10', '57.0.2987.133', '180.248.187.154');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('232', '5', '2017-05-04 16:03:44', 'Chrome', 'Windows 7', '57.0.2987.133', '180.248.187.154');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('233', '5', '2017-05-04 16:11:04', 'Chrome', 'Windows 7', '57.0.2987.133', '180.248.187.154');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('234', '5', '2017-05-06 11:21:52', 'Chrome', 'Windows 7', '57.0.2987.133', '180.248.187.154');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('235', '2', '2017-05-06 11:25:16', 'Chrome', 'Windows 10', '57.0.2987.133', '180.248.187.154');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('236', '3', '2017-05-06 11:26:16', 'Chrome', 'Windows 7', '57.0.2987.133', '180.248.187.154');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('237', '5', '2017-05-08 15:49:05', 'Chrome', 'Windows 7', '57.0.2987.133', '180.248.187.154');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('238', '5', '2017-05-09 10:35:29', 'Chrome', 'Windows 7', '57.0.2987.133', '180.248.187.154');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('239', '3', '2017-05-10 13:04:27', 'Safari', 'iOS', '602.1', '114.125.206.61');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('240', '5', '2017-05-10 13:54:18', 'Chrome', 'Windows 7', '57.0.2987.133', '180.248.187.154');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('241', '5', '2017-05-10 15:32:54', 'Chrome', 'Windows 7', '57.0.2987.133', '180.248.187.154');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('242', '3', '2017-05-10 20:22:44', 'Chrome', 'Mac OS X', '57.0.2987.133', '180.248.187.154');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('243', '2', '2017-05-12 09:34:55', 'Chrome', 'Windows 10', '57.0.2987.133', '180.248.187.154');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('244', '5', '2017-05-12 10:57:59', 'Chrome', 'Windows 7', '57.0.2987.133', '180.248.187.154');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('245', '5', '2017-05-12 11:09:59', 'Safari', 'iOS', '602.1', '180.248.187.154');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('246', '3', '2017-05-12 11:17:28', 'Chrome', 'Mac OS X', '57.0.2987.133', '180.248.187.154');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('247', '3', '2017-05-12 13:19:46', 'Chrome', 'Mac OS X', '57.0.2987.133', '180.248.187.154');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('248', '1', '2017-05-12 13:22:44', 'Firefox', 'Windows 7', '49.0', '180.248.235.148');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('249', '5', '2017-05-12 13:36:35', 'Chrome', 'Windows 7', '57.0.2987.133', '180.248.187.154');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('250', '3', '2017-05-12 15:41:36', 'Chrome', 'Mac OS X', '57.0.2987.133', '180.248.187.154');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('251', '5', '2017-05-12 16:41:56', 'Chrome', 'Windows 7', '57.0.2987.133', '180.248.187.154');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('252', '5', '2017-05-12 16:49:16', 'Chrome', 'Windows 7', '57.0.2987.133', '180.248.187.154');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('253', '5', '2017-05-13 11:24:38', 'Chrome', 'Windows 7', '57.0.2987.133', '180.248.238.169');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('254', '5', '2017-05-13 12:45:43', 'Safari', 'iOS', '602.1', '202.67.34.237');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('255', '5', '2017-05-15 09:20:48', 'Chrome', 'Windows 7', '57.0.2987.133', '180.248.238.169');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('256', '3', '2017-05-15 10:53:47', 'Chrome', 'Windows 7', '57.0.2987.133', '180.248.238.169');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('257', '5', '2017-05-15 10:57:42', 'Chrome', 'Windows 7', '57.0.2987.133', '180.248.238.169');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('258', '3', '2017-05-15 10:58:37', 'Chrome', 'Windows 7', '57.0.2987.133', '180.248.238.169');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('259', '5', '2017-05-15 12:11:03', 'Chrome', 'Windows 7', '57.0.2987.133', '180.248.238.169');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('260', '3', '2017-05-16 09:31:16', 'Safari', 'iOS', '602.1', '114.125.213.44');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('261', '3', '2017-05-16 12:10:54', 'Chrome', 'Mac OS X', '57.0.2987.133', '114.125.212.114');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('262', '5', '2017-05-17 10:22:28', 'Chrome', 'Windows 7', '57.0.2987.133', '180.248.238.169');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('263', '3', '2017-05-18 16:09:00', 'Chrome', 'Mac OS X', '57.0.2987.133', '180.248.238.169');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('264', '5', '2017-05-20 09:19:06', 'Chrome', 'Windows 7', '58.0.3029.110', '125.167.196.32');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('265', '5', '2017-05-22 15:10:32', 'Chrome', 'Windows 7', '58.0.3029.110', '125.167.196.32');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('266', '3', '2017-05-22 15:12:00', 'Chrome', 'Mac OS X', '58.0.3029.110', '125.167.196.32');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('267', '3', '2017-05-22 15:14:09', 'Chrome', 'Mac OS X', '58.0.3029.110', '125.167.196.32');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('268', '3', '2017-05-28 15:08:14', 'Chrome', 'Mac OS X', '58.0.3029.110', '180.248.185.206');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('269', '5', '2017-05-29 09:28:52', 'Chrome', 'Windows 7', '58.0.3029.110', '36.74.250.188');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('270', '2', '2017-05-29 11:40:48', 'Chrome', 'Windows 10', '58.0.3029.110', '36.74.250.188');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('271', '5', '2017-05-29 14:08:32', 'Chrome', 'Windows 7', '58.0.3029.110', '36.74.250.188');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('272', '1', '2017-05-30 14:45:52', 'Chrome', 'Windows 7', '58.0.3029.110', '110.136.77.144');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('273', '5', '2017-05-30 15:36:55', 'Chrome', 'Windows 7', '58.0.3029.110', '36.74.250.188');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('274', '5', '2017-05-31 09:55:24', 'Chrome', 'Windows 7', '58.0.3029.110', '125.167.197.23');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('275', '3', '2017-05-31 11:44:48', 'Safari', 'iOS', '602.1', '114.124.174.10');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('276', '5', '2017-05-31 14:45:07', 'Chrome', 'Windows 7', '58.0.3029.110', '125.167.197.23');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('277', '5', '2017-06-02 14:49:02', 'Chrome', 'Windows 7', '58.0.3029.110', '180.248.238.230');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('278', '3', '2017-06-03 13:16:28', 'Chrome', 'Mac OS X', '58.0.3029.110', '180.248.238.230');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('279', '5', '2017-06-05 13:37:06', 'Chrome', 'Windows 7', '58.0.3029.110', '180.248.238.230');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('280', '5', '2017-06-07 13:38:37', 'Chrome', 'Windows 7', '58.0.3029.110', '180.249.249.203');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('281', '3', '2017-06-08 00:21:08', 'Safari', 'iOS', '602.1', '180.249.249.203');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('282', '2', '2017-06-08 11:27:07', 'Chrome', 'Windows 10', '58.0.3029.110', '180.249.249.203');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('283', '3', '2017-06-12 16:21:23', 'Safari', 'iOS', '602.1', '114.124.140.198');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('284', '5', '2017-06-14 12:05:14', 'Chrome', 'Windows 7', '58.0.3029.110', '110.136.76.85');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('285', '5', '2017-06-15 13:24:13', 'Chrome', 'Windows 7', '58.0.3029.110', '110.136.76.85');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('286', '5', '2017-06-16 09:53:33', 'Chrome', 'Windows 7', '58.0.3029.110', '110.136.76.85');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('287', '5', '2017-06-17 10:37:31', 'Chrome', 'Windows 7', '58.0.3029.110', '36.84.64.136');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('288', '5', '2017-06-21 10:42:07', 'Chrome', 'Windows 7', '58.0.3029.110', '180.248.184.149');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('289', '5', '2017-06-21 14:53:06', 'Chrome', 'Windows 7', '58.0.3029.110', '180.248.184.149');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('290', '3', '2017-06-30 21:51:42', 'Chrome', 'Mac OS X', '58.0.3029.110', '114.125.203.201');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('291', '3', '2017-07-02 13:22:30', 'Safari', 'iOS', '602.1', '114.125.200.252');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('292', '3', '2017-07-02 13:25:51', 'Chrome', 'Mac OS X', '58.0.3029.110', '114.125.196.150');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('293', '2', '2017-07-03 13:41:45', 'Chrome', 'Windows 7', '59.0.3071.115', '180.249.250.209');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('294', '5', '2017-07-03 15:00:50', 'Chrome', 'Windows 7', '59.0.3071.115', '180.249.250.209');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('295', '2', '2017-07-03 15:22:28', 'Chrome', 'Windows 7', '59.0.3071.115', '180.249.250.209');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('296', '5', '2017-07-03 15:23:57', 'Chrome', 'Windows 7', '59.0.3071.115', '180.249.250.209');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('297', '5', '2017-07-04 14:36:50', 'Chrome', 'Windows 7', '59.0.3071.115', '180.249.250.209');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('298', '3', '2017-07-04 20:45:46', 'Chrome', 'Mac OS X', '58.0.3029.110', '114.124.170.116');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('299', '5', '2017-07-05 10:06:44', 'Chrome', 'Windows 7', '59.0.3071.115', '180.249.250.209');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('300', '2', '2017-07-05 10:11:21', 'Chrome', 'Windows 7', '59.0.3071.115', '180.249.250.209');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('301', '5', '2017-07-05 10:31:26', 'Chrome', 'Windows 7', '59.0.3071.115', '180.249.250.209');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('302', '3', '2017-07-06 10:37:17', 'Chrome', 'Windows 7', '59.0.3071.115', '180.248.236.146');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('303', '5', '2017-07-06 10:59:19', 'Chrome', 'Windows 7', '59.0.3071.115', '180.248.236.146');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('304', '5', '2017-07-06 13:39:45', 'Chrome', 'Windows 7', '59.0.3071.115', '180.248.236.146');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('305', '5', '2017-07-10 10:25:31', 'Chrome', 'Windows 7', '59.0.3071.115', '110.136.76.199');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('306', '5', '2017-07-11 09:52:36', 'Chrome', 'Windows 7', '59.0.3071.115', '110.136.76.199');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('307', '5', '2017-07-11 15:15:33', 'Chrome', 'Windows 7', '59.0.3071.115', '110.136.76.199');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('308', '5', '2017-07-11 16:42:21', 'Chrome', 'Windows 7', '59.0.3071.115', '110.136.76.199');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('309', '5', '2017-07-12 10:09:59', 'Chrome', 'Windows 7', '59.0.3071.115', '125.167.197.194');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('310', '5', '2017-07-14 10:21:25', 'Chrome', 'Windows 7', '59.0.3071.115', '36.84.64.150');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('311', '1', '2017-07-14 10:31:07', 'Firefox', 'Windows 7', '49.0', '180.248.235.171');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('312', '1', '2017-07-14 10:34:23', 'Firefox', 'Windows 7', '49.0', '180.248.235.171');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('313', '5', '2017-07-14 11:20:06', 'Chrome', 'Windows 7', '59.0.3071.115', '36.84.64.150');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('314', '5', '2017-07-18 13:06:29', 'Chrome', 'Windows 7', '59.0.3071.115', '36.84.64.137');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('315', '5', '2017-07-19 10:36:42', 'Chrome', 'Windows 7', '59.0.3071.115', '36.84.64.150');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('316', '1', '2017-07-19 12:44:45', 'Firefox', 'Windows 7', '49.0', '36.74.250.35');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('317', '5', '2017-07-19 14:02:15', 'Chrome', 'Windows 7', '59.0.3071.115', '36.84.64.150');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('318', '3', '2017-07-19 14:02:32', 'Chrome', 'Windows 7', '59.0.3071.115', '36.84.64.150');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('319', '5', '2017-07-19 14:13:37', 'Chrome', 'Windows 7', '59.0.3071.115', '36.84.64.150');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('320', '3', '2017-07-19 16:32:34', 'Chrome', 'Windows 7', '59.0.3071.115', '36.84.64.150');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('321', '5', '2017-07-19 16:33:53', 'Chrome', 'Windows 7', '59.0.3071.115', '36.84.64.150');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('322', '5', '2017-07-20 10:14:25', 'Chrome', 'Windows 7', '59.0.3071.115', '36.84.64.165');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('323', '5', '2017-07-20 13:48:56', 'Chrome', 'Windows 7', '59.0.3071.115', '36.84.64.165');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('324', '3', '2017-07-20 21:30:12', 'Safari', 'iOS', '602.1', '114.125.216.133');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('325', '2', '2017-07-21 09:54:33', 'Chrome', 'Windows 10', '59.0.3071.115', '180.249.254.251');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('326', '2', '2017-07-21 10:04:13', 'Chrome', 'Windows 10', '59.0.3071.115', '180.249.254.251');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('327', '2', '2017-07-21 10:22:49', 'Internet Explorer', 'Windows 7', '8.0', '125.160.82.54');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('328', '3', '2017-07-21 10:24:08', 'Internet Explorer', 'Windows 7', '8.0', '125.160.82.54');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('329', '2', '2017-07-21 10:25:51', 'Firefox', 'Windows 7', '54.0', '125.160.82.54');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('330', '3', '2017-07-23 13:57:35', 'Safari', 'iOS', '602.1', '114.125.182.3');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('331', '2', '2017-07-24 09:49:31', 'Chrome', 'Windows 10', '59.0.3071.115', '180.249.254.251');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('332', '3', '2017-07-24 09:54:19', 'Chrome', 'Windows 10', '59.0.3071.115', '180.249.254.251');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('333', '2', '2017-07-24 09:55:24', 'Chrome', 'Windows 10', '59.0.3071.115', '180.249.254.251');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('334', '1', '2017-07-25 17:51:02', 'Firefox', 'Windows 7', '49.0', '36.74.254.218');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('335', '2', '2017-07-26 11:48:18', 'Chrome', 'Windows 10', '59.0.3071.115', '125.160.92.90');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('336', '5', '2017-07-26 14:13:27', 'Chrome', 'Windows 10', '59.0.3071.115', '125.160.92.90');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('337', '5', '2017-07-26 17:55:34', 'Chrome', 'Windows 7', '59.0.3071.115', '120.188.7.43');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('338', '3', '2017-07-26 17:58:07', 'Chrome', 'Windows 7', '59.0.3071.115', '120.188.7.43');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('339', '5', '2017-07-26 18:01:56', 'Chrome', 'Windows 7', '59.0.3071.115', '120.188.7.43');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('340', '2', '2017-07-27 14:06:40', 'Chrome', 'Windows 10', '59.0.3071.115', '125.160.92.90');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('341', '2', '2017-07-29 10:38:22', 'Chrome', 'Windows 10', '59.0.3071.115', '110.136.72.212');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('342', '5', '2017-07-29 11:47:49', 'Chrome', 'Windows 7', '59.0.3071.115', '110.136.72.212');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('343', '3', '2017-07-29 12:14:01', 'Chrome', 'Mac OS X', '59.0.3071.115', '114.124.172.192');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('344', '5', '2017-07-29 12:52:00', 'Chrome', 'Windows 7', '59.0.3071.115', '110.136.72.212');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('345', '1', '2017-07-29 19:43:05', 'Firefox', 'Windows 7', '41.0', '180.248.167.29');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('346', '1', '2017-07-31 10:30:15', 'Chrome', 'Windows 7', '59.0.3071.115', '180.248.235.28');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('347', '5', '2017-07-31 11:24:50', 'Chrome', 'Windows 7', '59.0.3071.115', '180.249.249.159');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('348', '3', '2017-07-31 11:33:00', 'Chrome', 'Mac OS X', '59.0.3071.115', '114.124.142.234');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('349', '2', '2017-07-31 11:42:02', 'Chrome', 'Windows 10', '59.0.3071.115', '180.249.249.159');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('350', '5', '2017-07-31 14:17:09', 'Chrome', 'Windows 7', '59.0.3071.115', '180.249.249.159');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('351', '2', '2017-08-01 11:28:19', 'Chrome', 'Windows 10', '59.0.3071.115', '180.248.237.43');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('352', '5', '2017-08-01 15:11:53', 'Chrome', 'Windows 7', '59.0.3071.115', '180.248.237.43');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('353', '1', '2017-08-02 10:01:54', 'Firefox', 'Windows 7', '49.0', '180.248.232.45');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('354', '1', '2017-08-03 15:30:52', 'Firefox', 'Windows 7', '49.0', '36.84.64.132');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('355', '5', '2017-08-05 10:13:30', 'Chrome', 'Windows 7', '59.0.3071.115', '180.249.251.12');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('356', '3', '2017-08-05 10:16:38', 'Chrome', 'Windows 7', '59.0.3071.115', '180.249.251.12');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('357', '3', '2017-08-05 20:03:20', 'Chrome', 'Mac OS X', '60.0.3112.90', '114.125.183.17');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('358', '3', '2017-08-07 09:50:51', 'Chrome', 'Mac OS X', '60.0.3112.90', '114.125.188.17');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('359', '5', '2017-08-07 10:55:20', 'Chrome', 'Windows 7', '59.0.3071.115', '180.249.251.12');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('360', '5', '2017-08-08 13:30:57', 'Chrome', 'Windows 7', '59.0.3071.115', '180.249.251.12');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('361', '3', '2017-08-08 13:32:13', 'Chrome', 'Mac OS X', '60.0.3112.90', '114.125.218.119');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('362', '1', '2017-08-08 13:59:26', 'Firefox', 'Windows 7', '49.0', '36.74.249.205');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('363', '1', '2017-08-09 12:26:15', 'Firefox', 'Windows 7', '49.0', '36.84.64.163');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('364', '5', '2017-08-09 15:28:18', 'Chrome', 'Windows 7', '59.0.3071.115', '180.249.251.12');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('365', '5', '2017-08-10 10:17:47', 'Chrome', 'Windows 7', '60.0.3112.90', '180.249.251.12');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('366', '3', '2017-08-10 11:38:36', 'Chrome', 'Mac OS X', '60.0.3112.90', '114.124.147.245');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('367', '1', '2017-08-10 16:35:18', 'Firefox', 'Windows 7', '49.0', '36.74.255.16');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('368', '3', '2017-08-10 16:53:03', 'Chrome', 'Windows 7', '60.0.3112.90', '180.249.251.12');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('369', '2', '2017-08-10 16:53:12', 'Chrome', 'Windows 10', '60.0.3112.90', '180.249.251.12');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('370', '1', '2017-08-11 02:36:22', 'Firefox', 'Windows 7', '53.0', '202.67.35.26');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('371', '3', '2017-08-11 09:27:05', 'Chrome', 'Mac OS X', '60.0.3112.90', '114.125.201.31');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('372', '5', '2017-08-11 11:02:20', 'Chrome', 'Windows 7', '60.0.3112.90', '180.249.250.63');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('373', '5', '2017-08-11 11:15:09', 'Chrome', 'Windows 7', '60.0.3112.90', '180.249.250.63');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('374', '1', '2017-08-11 13:58:47', 'Firefox', 'Windows 7', '49.0', '36.84.64.135');
INSERT INTO `log_umeta` (`umeta_id`, `user_id`, `umeta_lastlogin`, `umeta_agent`, `umeta_platform`, `umeta_version`, `umeta_ip`) VALUES ('375', '2', '2017-08-12 11:17:40', 'Chrome', 'Windows 10', '60.0.3112.90', '180.249.250.63');


#
# TABLE STRUCTURE FOR: penerimaan_kategori
#

DROP TABLE IF EXISTS `penerimaan_kategori`;

CREATE TABLE `penerimaan_kategori` (
  `pkategori_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pkategori_nama` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`pkategori_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `penerimaan_kategori` (`pkategori_id`, `pkategori_nama`) VALUES ('1', 'TANDA JADI');
INSERT INTO `penerimaan_kategori` (`pkategori_id`, `pkategori_nama`) VALUES ('2', 'PENCAIRAN BANK');
INSERT INTO `penerimaan_kategori` (`pkategori_id`, `pkategori_nama`) VALUES ('3', 'UANG MUKA');


#
# TABLE STRUCTURE FOR: pengeluaran_jenis
#

DROP TABLE IF EXISTS `pengeluaran_jenis`;

CREATE TABLE `pengeluaran_jenis` (
  `pj_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pj_nama` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`pj_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `pengeluaran_jenis` (`pj_id`, `pj_nama`) VALUES ('1', 'Biaya Perolehan Tanah');
INSERT INTO `pengeluaran_jenis` (`pj_id`, `pj_nama`) VALUES ('2', 'Biaya Persiapan & Pengolahan Tanah');
INSERT INTO `pengeluaran_jenis` (`pj_id`, `pj_nama`) VALUES ('3', 'Biaya Legalitas & Perizinan');
INSERT INTO `pengeluaran_jenis` (`pj_id`, `pj_nama`) VALUES ('4', 'Biaya Prasarana, Sarana & Utilitas');
INSERT INTO `pengeluaran_jenis` (`pj_id`, `pj_nama`) VALUES ('5', 'Biaya Konstruksi Rumah');
INSERT INTO `pengeluaran_jenis` (`pj_id`, `pj_nama`) VALUES ('6', 'Biaya Pemasaran');
INSERT INTO `pengeluaran_jenis` (`pj_id`, `pj_nama`) VALUES ('7', 'Biaya Umum & Administrasi');
INSERT INTO `pengeluaran_jenis` (`pj_id`, `pj_nama`) VALUES ('8', 'Biaya Pajak & Bunga Pinjaman');


#
# TABLE STRUCTURE FOR: pengeluaran_kategori
#

DROP TABLE IF EXISTS `pengeluaran_kategori`;

CREATE TABLE `pengeluaran_kategori` (
  `pp_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pengeluaran_nama` varchar(100) DEFAULT NULL,
  `pp_kategori` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`pp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=latin1;

INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('5', 'Biaya Cut and Fill', '2');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('6', 'Biaya Pengukuran & Pematokan', '2');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('7', 'Biaya Pengurugan Badan Jalan', '2');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('8', 'Biaya Pengurugan Kavling Rumah/Fasum', '2');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('9', 'Biaya Pembangunan Gudang', '2');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('13', 'Harga Dasar Tanah', '1');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('14', 'Biaya Retribusi IMB [Type 36]', '3');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('15', 'Biaya Advis IMB [Type 36]', '3');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('16', 'Biaya Validasi Pajak [Type 36]', '3');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('17', 'Biaya Rekomendasi Kelurahan', '3');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('18', 'Biaya Rekomendasi Kecamatan', '3');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('19', 'Biaya UKL/UPL (AMDAL)', '3');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('20', 'Biaya IPPT & Siteplan', '3');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('21', 'Biaya PBB Kavling', '3');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('22', 'Biaya Sertifikat Kavling', '3');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('23', 'Biaya IPPT (BPN)', '3');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('25', 'Biaya KWH Meter [1.300 Va]', '4');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('26', 'Biaya Pembangunan Jembatan', '4');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('27', 'Biaya Pembangunan Drainase Depan', '4');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('28', 'Biaya Penggalian Drainase Belakang', '4');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('29', 'Biaya Penerangan Jalan Umum', '4');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('30', 'Biaya Pembangunan Gerbang', '4');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('31', 'Biaya Pembangunan Masjid', '4');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('32', 'Biaya Taman Lingkungan', '4');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('33', 'Biaya Pembangunan Rumah Type 36 (Th. 2017)', '5');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('34', 'Biaya Pembangunan Rumah Type 36 (Th. 2018)', '5');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('35', 'Biaya Pembangunan Rumah Type 36 (Th. 2019)', '5');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('36', 'Biaya Pembangunan Rumah Type 36 (Th. 2020)', '5');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('37', 'Biaya Cetak Brosur [A4]', '6');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('38', 'Biaya Cetak Poster [A3]', '6');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('39', 'Biaya Cetak Roll Up Banner [60x160]', '6');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('40', 'Biaya Cetak V Banner [80x300]', '6');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('41', 'Biaya Cetak Spanduk [100x500]', '6');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('43', 'Biaya Cetak Baliho [240x2200]', '6');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('44', 'Biaya Cetak Baliho [360x600]', '6');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('45', 'Biaya Cetak Umbul-Umbul [80x500]', '6');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('46', 'Biaya Pemasangan Media Iklan/Promo', '6');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('47', 'Biaya Desain Media Iklan/Promo', '6');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('48', 'Biaya Fee Direktur (RAVI)', '7');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('51', 'Biaya Fee General Manager (DELLA)', '7');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('52', 'Biaya Fee  Finance Direktur (UTIN)', '7');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('53', 'Biaya Fee Marketing Manager (FRANS)', '7');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('54', 'Biaya Fee Administrasi Manager (FANI)', '7');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('55', 'Biaya Fee Teknik Manager (ROVI)', '7');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('56', 'Biaya Fee Admin Bank & Notaris', '7');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('57', 'Biaya Fee Pemasaran/Penjualan', '7');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('58', 'Biaya Umum (VILAND PROPERTY)', '7');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('59', 'Biaya THR (VILAND PROPERTY)', '7');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('61', 'Biaya PPH Type 36 (Th. 2017)', '8');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('62', 'Biaya PPH Type 36 (Th. 2018)', '8');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('63', 'Biaya PPH Type 36 (Th. 2019)', '8');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('64', 'Biaya PPH Type 36 (Th. 2020)', '8');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('65', 'Biaya Bunga Pinjaman Bank', '8');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('66', 'Biaya Profit Investor', '8');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('67', 'Biaya Pajak Perolehan Tanah', '1');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('68', 'Biaya Rencana & Desain Project', '7');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('69', 'Biaya Appraisal', '7');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('70', 'Biaya Stand', '6');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('74', 'Biaya Notaris (APHT)', '8');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('76', 'Biaya Admin (KYG)', '8');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('77', 'Fee Pembelian Lahan', '1');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('78', 'Biaya Taman Rumah', '4');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('79', 'Biaya Jalan Perumahan', '4');
INSERT INTO `pengeluaran_kategori` (`pp_id`, `pengeluaran_nama`, `pp_kategori`) VALUES ('80', 'Biaya Bagi Hasil Lahan ( Elman Armadi )', '1');


#
# TABLE STRUCTURE FOR: rumah_kavling
#

DROP TABLE IF EXISTS `rumah_kavling`;

CREATE TABLE `rumah_kavling` (
  `kavling_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `rumah_id` bigint(20) DEFAULT NULL,
  `kavling_blok` varchar(50) DEFAULT NULL,
  `kavling_lb` varchar(255) DEFAULT NULL,
  `kavling_lt` varchar(255) DEFAULT NULL,
  `kavling_tipe` varchar(255) DEFAULT NULL,
  `kavling_harga` double DEFAULT NULL,
  `kavling_shm` enum('p','n','y') DEFAULT 'n',
  `kavling_shm_no` varchar(50) DEFAULT NULL,
  `kavling_imb` enum('p','n','y') DEFAULT 'n',
  `kavling_imb_no` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`kavling_id`),
  UNIQUE KEY `kavling_id` (`kavling_id`),
  KEY `rk_rumahid_fk` (`rumah_id`),
  CONSTRAINT `rk_rumahid_fk` FOREIGN KEY (`rumah_id`) REFERENCES `tb_rumah` (`rumah_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=339 DEFAULT CHARSET=latin1;

INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('2', '4', 'A.02', '45', '148', '45', '0', 'y', '2652', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('3', '4', 'A.03', '45', '148', '45', '0', 'y', '2651', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('4', '4', 'A.04', '45', '148', '45', '0', 'y', '2650', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('5', '4', 'A.05', '45', '148', '45', '0', 'y', '2649', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('6', '4', 'A.06', '45', '148', '45', '0', 'y', '2648', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('7', '4', 'A.07', '45', '148', '45', '0', 'y', '2647', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('8', '4', 'A.08', '45', '148', '45', '0', 'y', '2646', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('9', '4', 'A.09', '45', '148', '45', '0', 'y', '2645', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('10', '4', 'A.10', '45', '177', '45', '0', 'y', '2644', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('11', '4', 'B.01', '45', '147', '45', '0', 'y', '2618', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('12', '4', 'B.02', '45', '147', '45', '0', 'y', '2619', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('13', '4', 'B.03', '45', '147', '45', '0', 'y', '2620', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('14', '4', 'B.04', '45', '147', '45', '0', 'y', '2621', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('15', '4', 'B.05', '45', '147', '45', '0', 'y', '2622', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('16', '4', 'B.06', '45', '147', '45', '0', 'y', '2623', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('17', '4', 'B.07', '45', '147', '45', '0', 'y', '2624', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('18', '4', 'B.08', '45', '175', '45', '0', 'y', '2625', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('19', '4', 'C.02', '45', '147', '45', '220000000', 'y', '2611', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('20', '4', 'C.03', '45', '147', '45', '220000000', 'y', '2610', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('21', '4', 'C.04', '45', '147', '45', '220000000', 'y', '2609', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('22', '4', 'C.05', '45', '147', '45', '220000000', 'y', '2608', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('23', '4', 'C.06', '45', '147', '45', '220000000', 'y', '2607', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('24', '4', 'C.07', '45', '147', '45', '220000000', 'y', '2606', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('25', '4', 'C.08', '45', '175', '45', '227000000', 'y', '2605', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('26', '4', 'D.01', '45', '176', '45', '232000000', 'y', '2264', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('27', '4', 'D.02', '45', '147', '45', '225000000', 'y', '2265', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('28', '4', 'D.03', '45', '147', '45', '225000000', 'y', '2583', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('29', '4', 'D.04', '45', '147', '45', '225000000', 'y', '2584', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('30', '4', 'D.05', '45', '147', '45', '225000000', 'y', '2585', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('31', '4', 'D.06', '45', '147', '45', '225000000', 'y', '2586', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('32', '4', 'D.07', '45', '147', '45', '225000000', 'y', '2587', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('33', '4', 'D.08', '45', '147', '45', '225000000', 'y', '2588', 'y', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('34', '3', 'R.02', '65', '160', '65', '385000000', 'p', '', 'p', NULL);
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('35', '3', 'R.03', '65', '160', '65', '385000000', 'p', '', 'p', NULL);
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('36', '3', 'R.04', '65', '160', '65', '385000000', 'p', '', 'p', NULL);
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('37', '3', 'R.09', '65', '160', '65', '385000000', 'p', '', 'p', NULL);
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('38', '3', 'R.10', '65', '160', '65', '385000000', 'p', '', 'p', NULL);
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('39', '3', 'R.11', '65', '160', '65', '385000000', 'p', '', 'p', NULL);
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('40', '3', 'R.12', '65', '160', '65', '385000000', 'p', '', 'p', NULL);
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('41', '3', 'R.13', '65', '160', '65', '385000000', 'p', '', 'p', NULL);
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('42', '3', 'R.14', '65', '160', '65', '385000000', 'p', '', 'p', NULL);
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('43', '2', 'A.04', '36', '144', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('44', '2', 'A.05', '36', '144', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('45', '2', 'A.06', '36', '144', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('46', '2', 'A.07', '36', '144', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('47', '2', 'A.08', '36', '144', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('48', '2', 'A.09', '36', '144', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('49', '2', 'A.10', '36', '144', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('50', '2', 'A.11', '36', '144', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('51', '2', 'A.12', '36', '144', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('52', '2', 'A.13', '36', '144', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('53', '2', 'A.14', '36', '144', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('54', '2', 'A.15', '36', '144', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('55', '2', 'A.16', '36', '144', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('56', '2', 'A.17', '36', '144', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('57', '2', 'A.18', '36', '144', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('58', '2', 'A.19', '36', '144', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('60', '2', 'B.04', '36', '', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('61', '2', 'B.05', '36', '', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('62', '2', 'B.06', '36', '', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('63', '2', 'B.07', '36', '', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('64', '2', 'B.08', '36', '', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('65', '2', 'B.09', '36', '', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('66', '2', 'B.10', '36', '', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('67', '2', 'B.11', '36', '', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('68', '2', 'B.12', '36', '', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('69', '2', 'B.13', '36', '', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('70', '2', 'B.14', '36', '', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('71', '2', 'B.15', '36', '', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('72', '2', 'B.16', '36', '', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('73', '2', 'B.17', '36', '', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('74', '2', 'B.18', '36', '', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('78', '2', 'C.05', '36', '160', '36', '148000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('79', '2', 'C.06', '36', '160', '36', '138000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('80', '2', 'C.07', '36', '160', '36', '138000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('81', '2', 'C.08', '36', '160', '36', '138000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('82', '2', 'C.09', '36', '160', '36', '138000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('83', '2', 'C.10', '36', '160', '36', '138000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('84', '2', 'C.11', '36', '160', '36', '138000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('85', '2', 'C.12', '36', '160', '36', '138000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('86', '2', 'C.13', '36', '160', '36', '138000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('87', '2', 'C.14', '36', '160', '36', '148000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('88', '2', 'C.15', '36', '160', '36', '148000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('89', '2', 'C.16', '36', '160', '36', '148000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('90', '2', 'C.17', '36', '160', '36', '148000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('91', '2', 'C.18', '36', '160', '36', '138000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('93', '2', 'D.05', '36', '', '36', '140000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('94', '2', 'D.06', '36', '', '36', '151000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('95', '2', 'D.07', '36', '', '36', '151000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('96', '2', 'D.08', '36', '', '36', '151000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('97', '2', 'D.09', '36', '', '36', '140000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('98', '2', 'D.10', '36', '', '36', '140000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('99', '2', 'D.11', '36', '', '36', '140000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('100', '2', 'D.12', '36', '', '36', '140000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('101', '2', 'D.13', '36', '', '36', '151000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('102', '2', 'D.14', '36', '', '36', '140000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('103', '2', 'D.15', '36', '', '36', '151000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('104', '2', 'D.16', '36', '', '36', '140000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('105', '2', 'D.17', '36', '', '36', '140000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('106', '2', 'D.18', '36', '', '36', '155000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('108', '1', 'C.02', '36', '162', '36', '143000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('109', '1', 'C.03', '36', '166', '36', '137000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('110', '1', 'C.04', '36', '166', '36', '137000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('111', '1', 'C.05', '36', '166', '36', '137000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('112', '1', 'C.06', '36', '166', '36', '137000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('113', '1', 'C.07', '36', '166', '36', '137000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('114', '1', 'C.08', '36', '166', '36', '137000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('115', '1', 'C.09', '36', '166', '36', '137000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('116', '1', 'C.10', '36', '166', '36', '137000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('117', '1', 'C.11', '36', '166', '36', '137000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('118', '1', 'C.12', '36', '166', '36', '137000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('119', '1', 'C.13', '36', '166', '36', '137000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('120', '1', 'C.14', '36', '166', '36', '137000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('121', '1', 'C.15', '36', '166', '36', '137000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('122', '1', 'C.16', '36', '166', '36', '137000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('123', '1', 'C.17', '36', '166', '36', '137000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('124', '1', 'C.18', '36', '203', '36', '142000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('125', '1', 'D.01', '36', '198', '36', '148000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('126', '1', 'D.02', '36', '166', '36', '143000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('127', '1', 'D.03', '36', '166', '36', '135000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('128', '1', 'D.04', '36', '166', '36', '135000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('129', '1', 'D.05', '36', '166', '36', '128000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('130', '1', 'D.06', '36', '166', '36', '128000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('131', '1', 'D.07', '36', '166', '36', '135000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('132', '1', 'D.08', '36', '166', '36', '135000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('133', '1', 'D.09', '36', '166', '36', '135000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('134', '1', 'D.10', '36', '166', '36', '135000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('135', '1', 'D.11', '36', '166', '36', '135000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('136', '1', 'D.12', '36', '166', '36', '135000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('137', '1', 'D.13', '36', '166', '36', '135000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('138', '1', 'D.14', '36', '166', '36', '135000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('139', '1', 'D.15', '36', '166', '36', '135000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('140', '1', 'D.16', '36', '166', '36', '135000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('141', '1', 'D.17', '36', '166', '36', '135000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('142', '1', 'D.18', '36', '203', '36', '140000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('143', '1', 'E.02', '36', '162', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('144', '1', 'E.03', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('145', '1', 'E.04', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('146', '1', 'E.05', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('147', '1', 'E.06', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('148', '1', 'E.07', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('149', '1', 'E.08', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('150', '1', 'E.09', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('151', '1', 'E.10', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('152', '1', 'E.11', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('153', '1', 'E.12', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('154', '1', 'E.13', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('155', '1', 'E.14', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('156', '1', 'E.15', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('157', '1', 'E.16', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('158', '1', 'E.17', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('159', '1', 'E.18', '36', '203', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('160', '2', 'D.04', '36', '', '36', '140000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('161', '1', 'F.17', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('162', '1', 'F.16', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('163', '1', 'F.15', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('164', '1', 'F.14', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('165', '1', 'F.13', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('166', '1', 'F.12', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('167', '1', 'F.11', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('168', '1', 'F.05', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('169', '1', 'F.18', '36', '203', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('170', '1', 'F.10', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('171', '1', 'F.02', '36', '162', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('172', '1', 'F.03', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('173', '1', 'F.04', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('174', '1', 'F.01', '36', '180', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('175', '1', 'F.06', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('176', '1', 'F.07', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('177', '1', 'F.08', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('178', '1', 'F.09', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('179', '1', 'G.01', '36', '180', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('180', '1', 'G.02', '36', '162', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('181', '1', 'G.03', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('182', '1', 'G.04', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('183', '1', 'G.05', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('184', '1', 'G.06', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('185', '1', 'G.07', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('186', '1', 'G.08', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('187', '1', 'G.09', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('188', '1', 'G.10', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('189', '1', 'G.11', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('190', '1', 'G.12', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('191', '1', 'G.13', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('192', '1', 'G.14', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('193', '1', 'G.15', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('194', '1', 'G.16', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('195', '1', 'G.17', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('196', '1', 'G.18', '36', '203', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('197', '1', 'H.01', '36', '180', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('198', '1', 'H.02', '36', '162', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('199', '1', 'H.03', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('200', '1', 'H.04', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('201', '1', 'H.05', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('202', '1', 'H.06', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('203', '1', 'H.07', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('204', '1', 'H.08', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('205', '1', 'H.09', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('206', '1', 'H.10', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('207', '1', 'H.11', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('211', '1', 'H.15', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('212', '1', 'H.16', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('213', '1', 'H.17', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('214', '1', 'H.18', '36', '203', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('215', '1', 'I.01', '36', '203', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('216', '1', 'I.02', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('217', '1', 'I.03', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('218', '1', 'I.04', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('219', '1', 'I.05', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('220', '1', 'I.06', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('223', '1', 'I.07', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('224', '1', 'I.08', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('225', '1', 'I.09', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('226', '1', 'I.10', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('227', '1', 'I.11', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('228', '1', 'I.12', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('229', '1', 'I.13', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('230', '1', 'I.14', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('231', '1', 'I.15', '36', '203', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('232', '1', 'J.01', '36', '203', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('233', '1', 'J.02', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('234', '1', 'J.03', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('235', '1', 'J.04', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('236', '1', 'J.05', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('237', '1', 'J.06', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('238', '1', 'J.07', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('239', '1', 'J.08', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('240', '1', 'J.09', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('241', '1', 'J.10', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('242', '1', 'J.11', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('243', '1', 'J.12', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('244', '1', 'J.13', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('245', '1', 'J.14', '36', '166', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('246', '1', 'J.15', '36', '203', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('247', '5', 'A.02', '36', '171', '36', '123000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('248', '5', 'A.03', '36', '171', '36', '123000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('249', '5', 'A.04', '36', '171', '36', '123000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('250', '5', 'A.05', '36', '171', '36', '123000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('251', '5', 'A.06', '36', '171', '36', '50000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('252', '5', 'B.02', '36', '171', '36', '123000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('253', '5', 'B.03', '36', '171', '36', '123000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('254', '5', 'B.04', '36', '171', '36', '123000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('255', '5', 'B.05', '36', '171', '36', '123000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('256', '5', 'B.06', '36', '171', '36', '123000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('257', '5', 'A.07', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('258', '5', 'A.08', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('259', '5', 'A.09', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('260', '5', 'A.10', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('261', '5', 'A.11', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('262', '5', 'A.12', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('263', '5', 'A.13', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('264', '5', 'A.14', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('265', '5', 'A.15', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('266', '5', 'A.16', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('267', '5', 'A.17', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('268', '5', 'A.18', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('269', '5', 'A.19', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('270', '5', 'A.20', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('271', '5', 'A.21', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('272', '5', 'A.22', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('273', '5', 'B.07', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('274', '5', 'B.08', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('275', '5', 'B.09', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('276', '5', 'B.10', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('277', '5', 'B.11', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('278', '5', 'B.12', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('279', '5', 'B.13', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('280', '5', 'B.14', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('281', '5', 'B.15', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('282', '5', 'B.16', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('283', '5', 'B.17', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('284', '5', 'B.18', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('285', '5', 'B.19', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('286', '5', 'B.20', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('287', '5', 'B.21', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('288', '5', 'B.22', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('289', '5', 'C.01', '36', '209', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('290', '5', 'C.02', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('291', '5', 'C.03', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('292', '5', 'C.04', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('293', '5', 'C.05', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('294', '5', 'C.06', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('295', '5', 'C.07', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('296', '5', 'C.08', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('297', '5', 'C.09', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('298', '5', 'C.10', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('299', '5', 'C.11', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('300', '5', 'C.12', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('301', '5', 'C.13', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('302', '5', 'C.14', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('303', '5', 'C.15', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('304', '5', 'C.16', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('305', '5', 'C.17', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('306', '5', 'C.18', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('307', '5', 'C.19', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('308', '5', 'C.20', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('309', '5', 'C.21', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('310', '5', 'C.22', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('311', '5', 'C.23', '36', '209', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('312', '5', 'D.01', '36', '209', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('313', '5', 'D.02', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('314', '5', 'D.03', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('315', '5', 'D.04', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('316', '5', 'D.05', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('317', '5', 'D.06', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('318', '5', 'D.07', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('319', '5', 'D.08', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('320', '5', 'D.09', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('321', '5', 'D.10', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('322', '5', 'D.11', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('323', '5', 'D.12', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('324', '5', 'D.13', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('325', '5', 'D.14', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('326', '5', 'D.15', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('327', '5', 'D.16', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('328', '5', 'D.17', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('329', '5', 'D.18', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('330', '5', 'D.19', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('331', '5', 'D.20', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('332', '5', 'D.21', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('333', '5', 'D.22', '36', '171', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('334', '5', 'D.23', '36', '209', '36', '0', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('335', '5', 'A.01', '36', '209', '36', '128000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('336', '5', 'B.01', '36', '209', '36', '128000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('337', '1', 'C.01', '36', '162', '36', '145000000', 'p', '', 'p', '');
INSERT INTO `rumah_kavling` (`kavling_id`, `rumah_id`, `kavling_blok`, `kavling_lb`, `kavling_lt`, `kavling_tipe`, `kavling_harga`, `kavling_shm`, `kavling_shm_no`, `kavling_imb`, `kavling_imb_no`) VALUES ('338', '2', 'D.03', '36', '', '36', '155000000', 'p', '', 'p', '');


#
# TABLE STRUCTURE FOR: tb_agama
#

DROP TABLE IF EXISTS `tb_agama`;

CREATE TABLE `tb_agama` (
  `agama_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `agama_nama` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`agama_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `tb_agama` (`agama_id`, `agama_nama`) VALUES ('1', 'Islam');
INSERT INTO `tb_agama` (`agama_id`, `agama_nama`) VALUES ('2', 'Hindu');
INSERT INTO `tb_agama` (`agama_id`, `agama_nama`) VALUES ('3', 'Budha');
INSERT INTO `tb_agama` (`agama_id`, `agama_nama`) VALUES ('4', 'Katolik');
INSERT INTO `tb_agama` (`agama_id`, `agama_nama`) VALUES ('5', 'Kong Hu Cu');
INSERT INTO `tb_agama` (`agama_id`, `agama_nama`) VALUES ('6', 'Protestan');


#
# TABLE STRUCTURE FOR: tb_akad
#

DROP TABLE IF EXISTS `tb_akad`;

CREATE TABLE `tb_akad` (
  `akad_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `rumah_id` bigint(20) DEFAULT NULL,
  `akad_no` varchar(20) DEFAULT NULL,
  `akad_date` date DEFAULT '0000-00-00',
  `booking_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`akad_id`),
  KEY `akadRumah` (`rumah_id`),
  KEY `takad_bookingid_fk` (`booking_id`),
  CONSTRAINT `takad_bookingid_fk` FOREIGN KEY (`booking_id`) REFERENCES `tb_booking` (`booking_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `takad_rumahid_fk` FOREIGN KEY (`rumah_id`) REFERENCES `tb_rumah` (`rumah_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `tb_akad` (`akad_id`, `rumah_id`, `akad_no`, `akad_date`, `booking_id`) VALUES ('1', '1', '01/RK-PAK/VII/2017', '0000-00-00', '20');
INSERT INTO `tb_akad` (`akad_id`, `rumah_id`, `akad_no`, `akad_date`, `booking_id`) VALUES ('2', '1', '02/RK-PAK/VII/2017', '0000-00-00', '33');
INSERT INTO `tb_akad` (`akad_id`, `rumah_id`, `akad_no`, `akad_date`, `booking_id`) VALUES ('3', '1', '03/RK-PAK/VII/2017', '0000-00-00', '26');
INSERT INTO `tb_akad` (`akad_id`, `rumah_id`, `akad_no`, `akad_date`, `booking_id`) VALUES ('4', '1', '04/RK-PAK/VII/2017', '0000-00-00', '27');
INSERT INTO `tb_akad` (`akad_id`, `rumah_id`, `akad_no`, `akad_date`, `booking_id`) VALUES ('5', '1', '05/RK-PAK/VII/2017', '0000-00-00', '36');
INSERT INTO `tb_akad` (`akad_id`, `rumah_id`, `akad_no`, `akad_date`, `booking_id`) VALUES ('6', '1', '06/RK-PAK/VII/2017', '0000-00-00', '43');
INSERT INTO `tb_akad` (`akad_id`, `rumah_id`, `akad_no`, `akad_date`, `booking_id`) VALUES ('7', '1', '07/RK-PAK/VII/2017', '2017-07-22', '34');


#
# TABLE STRUCTURE FOR: tb_batal
#

DROP TABLE IF EXISTS `tb_batal`;

CREATE TABLE `tb_batal` (
  `batal_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `booking_id` bigint(20) DEFAULT NULL,
  `booking_no` varchar(20) DEFAULT NULL,
  `booking_harga` double(255,0) DEFAULT '0',
  `pelanggan_id` bigint(20) DEFAULT NULL,
  `rumah_id` bigint(20) DEFAULT NULL,
  `kavling_id` bigint(20) DEFAULT NULL,
  `booking_date` date DEFAULT '0000-00-00',
  `booking_batal` date DEFAULT '0000-00-00',
  `batal_status` enum('3','2','1') DEFAULT NULL,
  `batal_potongan` double(255,0) DEFAULT '0',
  PRIMARY KEY (`batal_id`),
  KEY `pelanggan_id` (`pelanggan_id`),
  KEY `rumah_id` (`rumah_id`),
  KEY `kavling_id` (`kavling_id`),
  CONSTRAINT `tb_batal_ibfk_1` FOREIGN KEY (`pelanggan_id`) REFERENCES `tb_pelanggan` (`pelanggan_id`) ON UPDATE CASCADE,
  CONSTRAINT `tb_batal_ibfk_2` FOREIGN KEY (`rumah_id`) REFERENCES `tb_rumah` (`rumah_id`) ON UPDATE CASCADE,
  CONSTRAINT `tb_batal_ibfk_3` FOREIGN KEY (`kavling_id`) REFERENCES `rumah_kavling` (`kavling_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tb_batal` (`batal_id`, `booking_id`, `booking_no`, `booking_harga`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `booking_batal`, `batal_status`, `batal_potongan`) VALUES ('1', '37', 'HR1-D06/011/170317', '128000000', '47', '1', '130', '2017-03-17', '2017-07-03', '3', '3000000');


#
# TABLE STRUCTURE FOR: tb_booking
#

DROP TABLE IF EXISTS `tb_booking`;

CREATE TABLE `tb_booking` (
  `booking_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `booking_no` varchar(20) DEFAULT NULL,
  `pelanggan_id` bigint(20) DEFAULT NULL,
  `rumah_id` bigint(20) DEFAULT NULL,
  `kavling_id` bigint(20) DEFAULT NULL,
  `booking_date` date DEFAULT '0000-00-00',
  `harga` double(255,0) DEFAULT '0',
  PRIMARY KEY (`booking_id`),
  UNIQUE KEY `booking_id` (`booking_id`),
  KEY `booking_no` (`booking_no`),
  KEY `tbbooking_rumahid_fk` (`rumah_id`) USING BTREE,
  KEY `tbbooking_pelangganid_fk` (`pelanggan_id`) USING BTREE,
  KEY `tbbooking_kavlingid_fk` (`kavling_id`) USING BTREE,
  CONSTRAINT `tbbooking_kavlingid_fk` FOREIGN KEY (`kavling_id`) REFERENCES `rumah_kavling` (`kavling_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbbooking_pelangganid_fk` FOREIGN KEY (`pelanggan_id`) REFERENCES `tb_pelanggan` (`pelanggan_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbbooking_rumahid_fk` FOREIGN KEY (`rumah_id`) REFERENCES `tb_rumah` (`rumah_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;

INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('2', 'HR2-C06/001/050317', '4', '2', '79', '2017-03-05', '138000000');
INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('3', 'HR2-C08/002/050317', '5', '2', '81', '2017-03-05', '138000000');
INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('4', 'HR2-C09/003/050317', '6', '2', '82', '2017-03-05', '138000000');
INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('5', 'HR2-C10/004/060317', '15', '2', '83', '2017-03-06', '138000000');
INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('6', 'HR2-C12/005/060317', '16', '2', '85', '2017-03-06', '138000000');
INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('8', 'HR2-D17/007/060317', '18', '2', '105', '2017-03-06', '140000000');
INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('9', 'HR2-D12/008/060317', '19', '2', '100', '2017-03-06', '140000000');
INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('10', 'HR2-D09/009/060317', '20', '2', '97', '2017-03-06', '140000000');
INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('11', 'HR2-C11/010/060317', '21', '2', '84', '2017-03-06', '138000000');
INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('12', 'HR2-C18/011/060317', '22', '2', '91', '2017-03-06', '138000000');
INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('14', 'HR2-C13/012/060317', '24', '2', '86', '2017-03-06', '138000000');
INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('15', 'HR2-D11/013/060317', '25', '2', '99', '2017-03-06', '140000000');
INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('17', 'HR2-D04/014/060317', '27', '2', '160', '2017-03-06', '140000000');
INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('18', 'HR2-D10/015/060317', '28', '2', '98', '2017-03-06', '140000000');
INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('19', 'HR2-C05/016/060317', '29', '2', '78', '2017-03-06', '148000000');
INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('20', 'HR1-C05/001/060317', '30', '1', '111', '2017-03-06', '137000000');
INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('22', 'HR1-D01/003/060317', '32', '1', '125', '2017-03-06', '148000000');
INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('23', 'HR1-D02/004/060317', '33', '1', '126', '2017-03-06', '143000000');
INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('26', 'HR1-D03/007/060317', '36', '1', '127', '2017-03-06', '135000000');
INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('27', 'HR1-D04/008/060317', '37', '1', '128', '2017-03-06', '135000000');
INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('29', 'HR2-D05/008/080317', '39', '2', '93', '2017-03-06', '140000000');
INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('30', 'HR2-D07/008/090317', '40', '2', '95', '2017-03-09', '151000000');
INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('31', 'HR2-D14/008/130317', '41', '2', '102', '2017-03-13', '140000000');
INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('32', 'HR2-D16/008/130317', '42', '2', '104', '2017-03-13', '140000000');
INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('33', 'HR1-C18/010/150317', '43', '1', '124', '2017-03-15', '142000000');
INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('34', 'HR1-D18/010/150317', '44', '1', '142', '2017-03-15', '140000000');
INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('36', 'HR1-D05/011/170317', '46', '1', '129', '2017-03-17', '128000000');
INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('40', 'HR2-C07/008/240717', '50', '2', '80', '2017-05-10', '138000000');
INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('41', 'HR2-D03/008/240717', '51', '2', '338', '2017-07-18', '155000000');
INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('42', 'HR2-D08/008/240717', '52', '2', '96', '2017-07-24', '151000000');
INSERT INTO `tb_booking` (`booking_id`, `booking_no`, `pelanggan_id`, `rumah_id`, `kavling_id`, `booking_date`, `harga`) VALUES ('43', 'HR1-D06/011/240717', '53', '1', '130', '2017-04-18', '128000000');


#
# TABLE STRUCTURE FOR: tb_data_btn
#

DROP TABLE IF EXISTS `tb_data_btn`;

CREATE TABLE `tb_data_btn` (
  `db_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `booking_id` bigint(20) DEFAULT NULL,
  `db_status` enum('p','n','y') DEFAULT 'n',
  `db_date` date DEFAULT '0000-00-00',
  PRIMARY KEY (`db_id`),
  KEY `tbdb_bookingid_fk` (`booking_id`) USING BTREE,
  CONSTRAINT `tbdb_bookingid_fk` FOREIGN KEY (`booking_id`) REFERENCES `tb_booking` (`booking_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

INSERT INTO `tb_data_btn` (`db_id`, `booking_id`, `db_status`, `db_date`) VALUES ('1', '20', 'y', '2017-04-10');
INSERT INTO `tb_data_btn` (`db_id`, `booking_id`, `db_status`, `db_date`) VALUES ('2', '33', 'y', '2017-04-10');
INSERT INTO `tb_data_btn` (`db_id`, `booking_id`, `db_status`, `db_date`) VALUES ('3', '26', 'y', '2017-04-10');
INSERT INTO `tb_data_btn` (`db_id`, `booking_id`, `db_status`, `db_date`) VALUES ('4', '27', 'y', '2017-04-10');
INSERT INTO `tb_data_btn` (`db_id`, `booking_id`, `db_status`, `db_date`) VALUES ('5', '23', 'y', '0000-00-00');
INSERT INTO `tb_data_btn` (`db_id`, `booking_id`, `db_status`, `db_date`) VALUES ('6', '36', 'y', '0000-00-00');
INSERT INTO `tb_data_btn` (`db_id`, `booking_id`, `db_status`, `db_date`) VALUES ('7', '43', 'y', '0000-00-00');
INSERT INTO `tb_data_btn` (`db_id`, `booking_id`, `db_status`, `db_date`) VALUES ('8', '34', 'y', '0000-00-00');
INSERT INTO `tb_data_btn` (`db_id`, `booking_id`, `db_status`, `db_date`) VALUES ('9', '19', 'y', '0000-00-00');
INSERT INTO `tb_data_btn` (`db_id`, `booking_id`, `db_status`, `db_date`) VALUES ('10', '2', 'n', '0000-00-00');
INSERT INTO `tb_data_btn` (`db_id`, `booking_id`, `db_status`, `db_date`) VALUES ('11', '40', 'y', '0000-00-00');
INSERT INTO `tb_data_btn` (`db_id`, `booking_id`, `db_status`, `db_date`) VALUES ('12', '3', 'y', '0000-00-00');
INSERT INTO `tb_data_btn` (`db_id`, `booking_id`, `db_status`, `db_date`) VALUES ('13', '4', 'y', '0000-00-00');
INSERT INTO `tb_data_btn` (`db_id`, `booking_id`, `db_status`, `db_date`) VALUES ('14', '11', 'y', '0000-00-00');
INSERT INTO `tb_data_btn` (`db_id`, `booking_id`, `db_status`, `db_date`) VALUES ('15', '5', 'y', '0000-00-00');
INSERT INTO `tb_data_btn` (`db_id`, `booking_id`, `db_status`, `db_date`) VALUES ('16', '6', 'y', '0000-00-00');
INSERT INTO `tb_data_btn` (`db_id`, `booking_id`, `db_status`, `db_date`) VALUES ('17', '14', 'y', '0000-00-00');
INSERT INTO `tb_data_btn` (`db_id`, `booking_id`, `db_status`, `db_date`) VALUES ('18', '12', 'y', '0000-00-00');
INSERT INTO `tb_data_btn` (`db_id`, `booking_id`, `db_status`, `db_date`) VALUES ('19', '32', 'y', '0000-00-00');
INSERT INTO `tb_data_btn` (`db_id`, `booking_id`, `db_status`, `db_date`) VALUES ('20', '8', 'y', '0000-00-00');


#
# TABLE STRUCTURE FOR: tb_jaminan
#

DROP TABLE IF EXISTS `tb_jaminan`;

CREATE TABLE `tb_jaminan` (
  `jaminan_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `booking_id` bigint(20) DEFAULT NULL,
  `jaminan_date` date DEFAULT '0000-00-00',
  `jaminan_expired` date DEFAULT NULL,
  PRIMARY KEY (`jaminan_id`),
  KEY `tbjaminan_bookingid_fk` (`booking_id`) USING BTREE,
  CONSTRAINT `tbjaminan_bookingid_fk` FOREIGN KEY (`booking_id`) REFERENCES `tb_booking` (`booking_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=FIXED;

#
# TABLE STRUCTURE FOR: tb_jenis_pembatalan
#

DROP TABLE IF EXISTS `tb_jenis_pembatalan`;

CREATE TABLE `tb_jenis_pembatalan` (
  `pembatalan_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pembatalan_nama` varchar(255) DEFAULT NULL,
  `pembatalan_jumlah` double(255,0) DEFAULT '0',
  PRIMARY KEY (`pembatalan_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `tb_jenis_pembatalan` (`pembatalan_id`, `pembatalan_nama`, `pembatalan_jumlah`) VALUES ('1', 'Tidak Lolos BI Checking', '0');
INSERT INTO `tb_jenis_pembatalan` (`pembatalan_id`, `pembatalan_nama`, `pembatalan_jumlah`) VALUES ('2', 'Pembatalan Sepihak', '0');
INSERT INTO `tb_jenis_pembatalan` (`pembatalan_id`, `pembatalan_nama`, `pembatalan_jumlah`) VALUES ('3', 'Ditolak Bank', '0');


#
# TABLE STRUCTURE FOR: tb_lpa
#

DROP TABLE IF EXISTS `tb_lpa`;

CREATE TABLE `tb_lpa` (
  `lpa_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `lpa_no` varchar(20) DEFAULT NULL,
  `rumah_id` bigint(20) DEFAULT NULL,
  `lpa_tanggal` date DEFAULT '0000-00-00',
  `booking_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`lpa_id`),
  KEY `lpa_rumahid_fk` (`rumah_id`),
  KEY `lpa_bokingid_fk` (`booking_id`),
  CONSTRAINT `lpa_bokingid_fk` FOREIGN KEY (`booking_id`) REFERENCES `tb_booking` (`booking_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `lpa_rumahid_fk` FOREIGN KEY (`rumah_id`) REFERENCES `tb_rumah` (`rumah_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `tb_lpa` (`lpa_id`, `lpa_no`, `rumah_id`, `lpa_tanggal`, `booking_id`) VALUES ('1', '01/RK-LPA/XII/2017', '1', '0000-00-00', '20');
INSERT INTO `tb_lpa` (`lpa_id`, `lpa_no`, `rumah_id`, `lpa_tanggal`, `booking_id`) VALUES ('2', '02/RK-LPA/XII/2017', '1', '0000-00-00', '33');
INSERT INTO `tb_lpa` (`lpa_id`, `lpa_no`, `rumah_id`, `lpa_tanggal`, `booking_id`) VALUES ('3', '03/RK-LPA/XII/2017', '1', '0000-00-00', '23');
INSERT INTO `tb_lpa` (`lpa_id`, `lpa_no`, `rumah_id`, `lpa_tanggal`, `booking_id`) VALUES ('4', '04/RK-LPA/XII/2017', '1', '0000-00-00', '26');
INSERT INTO `tb_lpa` (`lpa_id`, `lpa_no`, `rumah_id`, `lpa_tanggal`, `booking_id`) VALUES ('5', '05/RK-LPA/XII/2017', '1', '0000-00-00', '27');
INSERT INTO `tb_lpa` (`lpa_id`, `lpa_no`, `rumah_id`, `lpa_tanggal`, `booking_id`) VALUES ('6', '06/RK-LPA/XII/2017', '1', '0000-00-00', '36');
INSERT INTO `tb_lpa` (`lpa_id`, `lpa_no`, `rumah_id`, `lpa_tanggal`, `booking_id`) VALUES ('7', '07/RK-LPA/XII/2017', '1', '0000-00-00', '43');
INSERT INTO `tb_lpa` (`lpa_id`, `lpa_no`, `rumah_id`, `lpa_tanggal`, `booking_id`) VALUES ('8', '08/RK-LPA/XII/2017', '1', '0000-00-00', '34');


#
# TABLE STRUCTURE FOR: tb_ots
#

DROP TABLE IF EXISTS `tb_ots`;

CREATE TABLE `tb_ots` (
  `ots_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `booking_id` bigint(20) DEFAULT NULL,
  `ots_status` enum('y','n') DEFAULT 'n',
  `ots_date` date DEFAULT '0000-00-00',
  PRIMARY KEY (`ots_id`),
  KEY `ots_bookingid_fk` (`booking_id`),
  CONSTRAINT `ots_bookingid_fk` FOREIGN KEY (`booking_id`) REFERENCES `tb_booking` (`booking_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

INSERT INTO `tb_ots` (`ots_id`, `booking_id`, `ots_status`, `ots_date`) VALUES ('1', '33', 'y', '0000-00-00');
INSERT INTO `tb_ots` (`ots_id`, `booking_id`, `ots_status`, `ots_date`) VALUES ('2', '26', 'y', '0000-00-00');
INSERT INTO `tb_ots` (`ots_id`, `booking_id`, `ots_status`, `ots_date`) VALUES ('3', '27', 'y', '0000-00-00');
INSERT INTO `tb_ots` (`ots_id`, `booking_id`, `ots_status`, `ots_date`) VALUES ('4', '20', 'y', '0000-00-00');
INSERT INTO `tb_ots` (`ots_id`, `booking_id`, `ots_status`, `ots_date`) VALUES ('5', '23', 'y', '0000-00-00');
INSERT INTO `tb_ots` (`ots_id`, `booking_id`, `ots_status`, `ots_date`) VALUES ('6', '36', 'y', '0000-00-00');
INSERT INTO `tb_ots` (`ots_id`, `booking_id`, `ots_status`, `ots_date`) VALUES ('7', '43', 'y', '0000-00-00');
INSERT INTO `tb_ots` (`ots_id`, `booking_id`, `ots_status`, `ots_date`) VALUES ('8', '34', 'y', '0000-00-00');
INSERT INTO `tb_ots` (`ots_id`, `booking_id`, `ots_status`, `ots_date`) VALUES ('9', '19', 'y', '0000-00-00');
INSERT INTO `tb_ots` (`ots_id`, `booking_id`, `ots_status`, `ots_date`) VALUES ('10', '40', 'y', '0000-00-00');
INSERT INTO `tb_ots` (`ots_id`, `booking_id`, `ots_status`, `ots_date`) VALUES ('11', '3', 'y', '0000-00-00');
INSERT INTO `tb_ots` (`ots_id`, `booking_id`, `ots_status`, `ots_date`) VALUES ('12', '4', 'y', '0000-00-00');
INSERT INTO `tb_ots` (`ots_id`, `booking_id`, `ots_status`, `ots_date`) VALUES ('13', '11', 'y', '0000-00-00');
INSERT INTO `tb_ots` (`ots_id`, `booking_id`, `ots_status`, `ots_date`) VALUES ('14', '5', 'y', '0000-00-00');
INSERT INTO `tb_ots` (`ots_id`, `booking_id`, `ots_status`, `ots_date`) VALUES ('15', '6', 'y', '0000-00-00');
INSERT INTO `tb_ots` (`ots_id`, `booking_id`, `ots_status`, `ots_date`) VALUES ('16', '14', 'y', '0000-00-00');
INSERT INTO `tb_ots` (`ots_id`, `booking_id`, `ots_status`, `ots_date`) VALUES ('17', '12', 'y', '0000-00-00');
INSERT INTO `tb_ots` (`ots_id`, `booking_id`, `ots_status`, `ots_date`) VALUES ('18', '32', 'y', '0000-00-00');
INSERT INTO `tb_ots` (`ots_id`, `booking_id`, `ots_status`, `ots_date`) VALUES ('19', '8', 'y', '0000-00-00');


#
# TABLE STRUCTURE FOR: tb_pelanggan
#

DROP TABLE IF EXISTS `tb_pelanggan`;

CREATE TABLE `tb_pelanggan` (
  `pelanggan_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pelanggan_ktp` varchar(255) DEFAULT NULL,
  `pelanggan_nama` varchar(255) DEFAULT NULL,
  `pelanggan_agama` bigint(20) DEFAULT NULL,
  `pelanggan_jk` enum('p','l') DEFAULT 'l',
  `pelanggan_ttl` varchar(255) DEFAULT '0000-00-00',
  `pelanggan_alamat` varchar(255) DEFAULT NULL,
  `pelanggan_alamat_surat` varchar(255) DEFAULT NULL,
  `pelanggan_kontak` varchar(50) DEFAULT NULL,
  `pelanggan_pekerjaan` varchar(255) DEFAULT NULL,
  `pelanggan_datetime` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`pelanggan_id`),
  KEY `pelanggan_ktp` (`pelanggan_ktp`),
  KEY `pelanggan_agama` (`pelanggan_agama`),
  CONSTRAINT `tb_pelanggan_ibfk_1` FOREIGN KEY (`pelanggan_agama`) REFERENCES `tb_agama` (`agama_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=latin1;

INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('4', '6107044109960001', 'NADIA SEPTIANTI', '1', 'p', 'BUMI EMAS, 01 SEPTEMBER 1996', 'JL. GEREJA PROTESTAN NO.35, RT/RW : 006/003, KEL. BUMI EMAS, KEC. BENGKAYANG, KAB. BENGKAYANG', 'JL. GEREJA PROTESTAN NO.35, RT/RW : 006/003, KEL. BUMI EMAS, KEC. BENGKAYANG, KAB. BENGKAYANG', '089655215223', 'KEPOLISIAN RI (POLRI)', '2017-03-05 18:54:51');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('5', '6101056802900003', 'JENNIFER YOHANA, F.S', '6', 'p', 'JAKARTA, 28 FEBRUARI 1990', 'JL. BANJAR PESISIR NO.09, RT/RW : 004/004, KEL. PEMANGKAT KOTA, KEC. PEMANGKAT, KAB. SAMBAS', 'JL. BANJAR PESISIR NO.09, RT/RW : 004/004, KEL. PEMANGKAT KOTA, KEC. PEMANGKAT, KAB. SAMBAS', '085245618618', 'PERAWAT', '2017-03-05 19:05:08');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('6', '6103071302900002', 'SUSBIYATNO', '1', 'l', 'SINGKAWANG, 13 FEBRUARI 1990', 'JL. SUBARANG, RT/RW : 010/001, KEL. NYARUMKOP, KEC. SINGKAWANG TIMUR, KOTA SINGKAWANG', 'JL. SUBARANG, RT/RW : 010/001, KEL. NYARUMKOP, KEC. SINGKAWANG TIMUR, KOTA SINGKAWANG', '082154888217', 'WIRASWASTA', '2017-03-05 19:11:31');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('15', '6172011304750003', 'SUBHAN', '1', 'l', 'SINGKAWANG, 13 APRIL 1975', 'TEPI KAPUAS, RT/RW 016/004 KEL.PENITI DALAM 1 KEC. SEGEDONG, KAB. MEMPAWAH', 'JL. IMAM BONJOL', '085332615515', 'KARYAWAN SWASTA', '2017-03-06 09:37:59');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('16', '3204392611930001', 'TRIYANDI KESATRIA ANUGRAH', '1', 'l', 'SINGKAWANG, 26 NOVEMBER 1993', 'PASAR KIDUL, RT/RW 002/009 KEL. CIWIDEY KEC. CIWIDEY, KAB. BANDUNG', 'JL. IMAM BONJOL NO.20, PONTIANAK', '082119108118', 'KARYAWAN SWASTA', '2017-03-06 09:46:12');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('17', '6172013112790005', 'PRIYONO PRATAMA', '1', 'l', 'NYARUMKOP, 31 DESEMBER 1979', 'JL. PAHLAWAN GG. MESJID NO.17, RT/RW 023/007 KEL. ROBAN KEC,SINGKAWANG TENGAH, KOTA SINGKAWANG', 'JL. IMAM BONJOL NO. 29. PONTIANAK', '082153519220', 'WIRASAWSTA', '2017-03-06 09:56:40');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('18', '1209212907910001', 'RUDI HENDRIKO DAMANIK', '6', 'l', 'BANDAR SELAMAT, 27 JULI 1991', 'JL. MERANTI NO.27, RT/RW 041/013 KEL. ROBAN KEC. SINGKAWANG TENGAH, KOTA SINGKAWANG', 'JL. IMAM BONJOL NO.29, PONTIANAK', '081346364630', 'KARYAWAN SWASTA', '2017-03-06 10:09:57');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('19', '6172012409540001', 'TOMMY SEPTIAN', '1', 'l', 'SINGKAWANG, 24 SEPTEMBER 1994', 'JL. DEMANG AKUB, RT/RW 003/002 KEL. SUNGAI BULAN KEC. SINGKAWANG UTARA, KOTA SINGKAWANG', 'JL. IMAM BONJOL NO.29, PONTIANAK', '081256639967 081256217827', 'KARYAWAN SWASTA', '2017-03-06 10:13:58');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('20', '6172015210900001', 'ADE IRMASARI', '1', 'p', 'SINGKAWANG, 12 OKTOBER 1990', 'JL. DURIAN NO.75, RT/RW 037/005 KEL.ROBAN KEC.SINGKAWANG TENGAH, KOTA SINGKAWANG', 'JL. IMAM BONJOL NO.29, PONTIANAK', '085246514609', 'PEGAWAI NEGERI SIPIL (PNS)', '2017-03-06 10:18:22');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('21', '6107086201900002', 'RIZA SUSANTI', '1', 'p', 'SINGKAWANG, 22 JANUARI 1990', 'JL. MAWAR, RT/RW 009/003 KEL. SEKIP LAMA KEC. SINGKAWANG TENGAH, KOTA SINGKAWANG', 'JL. IMAM BONJOL NO.29, PONTIANAK', '085750002667', 'WIRASWASTA', '2017-03-06 10:21:11');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('22', '6172016604930002', 'YOLANDA AFRICIA MAMPUK', '6', 'p', 'SINGKAWANG, 26 APRIL 1993', 'JL. SEMANGKA 1 NO 117, RT/RW 058/006 KEL. ROOBAN KEC. SINGKAWANG TENGAH, KOTA SINGKAWANG', 'JL. IMAM BONJOL NO. 29, SINGKAWANG', '082148267800 082155807552', 'WIRASWASTA', '2017-03-06 10:31:02');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('24', '6172040407880002', 'DEBI JULIANDI', '1', 'l', 'SETAPUK BESAR, 04 JULI 1988', 'JL.MAHAD USMAN, RT/RW 006/003 KEL. SETAPUK BESAR KEC.SINGKAWANG UTARA, KOTA SINGKAWANG', 'JL. IMAM BONJOL NO.29, PONTIANAK', '085350010115', 'KARYAWAN SWASTA', '2017-03-06 10:43:34');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('25', '6172017009820002', 'ELVRYDA MARTHA LENA S. S.SOS', '6', 'p', 'SINGKAWANG, 30 SEPTEMBER 1982', 'JL. BINTARA ASR. NATUNA NO.H 4, RT/RW 011/004 KEL. SEKIP LAMA KEC. SINGKAWANG TENGAH, KOTA SINGKAWANG', 'JL. IMAM BONJOL NO.29, PONTIANAK', '081352648993', 'KARYAWAN SWASTA', '2017-03-06 10:56:33');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('26', '6171052703750015', 'DEDY MAULI', '1', 'l', 'PONTIANAK, 27 MARET 1975', 'GG. TRIJAYA NO.10, RT/RW 005/008 KEL. SEI. BANGKONG KEC. PONTIANAK KOTA, KOTA PONTIANAK', 'JL. IMAM BONJOL NO.29, PONTIANAK', '081256639967 081256217827', 'PEGAWAI NEGERI SIPIL (PNS)', '2017-03-06 11:03:34');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('27', '6172015005910001', 'IRA IKASA PUTRI', '1', 'p', 'SAMBAS , 10 MEI 1991', 'JL. SIAGA GG. AMAL 1, RT/RW 040/002 KEL. ROBAN KEC.SINGKAWANG TENGAH, KOTA SINGKAWANG', 'JL. IMAM BONJOL NO.29, PONTIANAK', '082155808944', 'KARYAWAN SWASTA', '2017-03-06 11:11:32');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('28', '6172011102760003', 'ANDI PRAMONO', '1', 'l', 'PONTIANAK, 11 FEBRUARI 1976', 'JL. RAMBUTAN NO.123, RT/RW 039/013 KEL.ROBAN KEC.SINGKAWANG TENGAH, KOTA SINGKAWANG', 'JL. IMAM BONJOL NO. 29, PONTIANAK', '085828486680', 'WIRASWASTA', '2017-03-06 11:15:37');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('29', '6101045210920005', 'LEGIANA', '4', 'p', 'SEI. ENAU, 12 OKTOBER 1992', 'SEI.ENAU, RT/RW 004/004 KEL.MARIBAS KEC.TEBAS, KAB. SAMBAS', 'JL. IMAM BONJOL NO.29, PONTIANAK', '082250684384 082155173057', 'KARYAWAN SWASTA', '2017-03-06 11:26:44');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('30', '6101075202790002', 'LIZA WATI', '1', 'p', 'SUNGAI DAUN, 12 FEBRUARI 1979', 'DUSUN HILIR, RT/RW 002/001 KEL. SUNGAI DAUN KEC.SELAKAU, KAB.SAMBAS', 'JL. IMAM BONJOL NO.29, PONTIANAK', '081345941233', 'WIRASWASTA', '2017-03-06 11:33:40');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('31', '6171051408950008', 'RIKI ANUGRAH ZULKARNAIN', '1', 'l', 'PONTIANAK, 14 AGUSTUS 1995', 'JL. RAMBUTAN NO.79, RT/RW 039/013 KEL. ROBAN KEC. SINGKAWANG TENGAH, KOTA SINGKAWANG', 'JL. IMAM BONJOL NO.29, PONTIANAK', '085246596504', 'KARYAWAN SWASTA', '2017-03-06 11:41:13');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('32', '6171015503920003', 'VELLEN WIBOWO', '3', 'p', 'PONTIANAK, 15 MARET 1992', 'JL.H.AGUS SALIM NO.72-74-76, RT/RW 001/002 KEL.BENUA MELAYU DARAT KEC.PONTIANAK SELATAN, KOTA PONTIANAK', 'JL. IMAM BONJOL NO.29, PONTIANAK', '0811560456', 'KARYAWAN SWASTA', '2017-03-06 11:45:59');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('33', '6171017003950002', 'VELLIKA WIBOWO', '3', 'p', 'PONTIANAK, 30 MARET 1995', 'JL.H.AGUS SALIM NO.72-74-76, RT/RW 001/002 KEL. BENUA MELAYU DARAT, KC. PONTIANAK SELATAN, KOTA PONTIANAK', 'JL. IMAM BONJOL NO.29, PONTIANAK', '0811560456', 'KARYAWAN SWASTA', '2017-03-06 11:49:33');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('34', '6172025406870008', 'ISVAN SONIA MERCY SELLY', '1', 'p', 'JAKARTA, 14 JUNI 1987', 'JL. PEMBANGUNAN NO.15, RT/RW 005/002 KEL. TENGAH KEC.SINGKAWANG BARAT, KOTA SINGKAWANG', 'JL. IMAM BONJOL NO.29, PONTIANAK', '085750333999', 'WIRASWASTA', '2017-03-06 11:54:00');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('35', '6171020406710010', 'SAWALUDDIN', '1', 'l', 'PONTIANAK, 04 JUNI 1971', 'JL.TJ.RAYA 1 GG.USAHA BERSAMA, RT/RW 002/005 KEL.DALAM BUGIS KEC.PONTIANAK TIMUR, KOTA PONTIANAK', 'JL. IMAM BONJOL NO.29. PONTIANAK', '0811560456', 'KARYAWAN SWASTA', '2017-03-06 13:26:19');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('36', '6171020505730013', 'MUHAMMAD', '1', 'l', 'PONTIANAK, 05 MEI 1973', 'JL. TANJUNG RAYA 1, RT/RW 004/005 KEL DALAM BUGIS KEC.PONTIANAK TIMU, KOTA PONTIANAK', 'JL. IMAM BONJOL NO.29, PONTIANAK', '0811560456', 'KARYAWAN SWASTA', '2017-03-06 13:29:51');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('37', '6171020407960003', 'RUSDIMAN', '1', 'l', 'PONTIANAK, 04 JULI 1996', 'JL. TJ. RAYA 1 GG.AMAL, RT/RW 004/005 KEL. DALAM BUGIS KEC.PONTIANAK TIMUR, KOTA PONTIANAK', 'JL. IMAM BONJOL NO.29, PONTIANAK', '0811560456', 'KARYAWAN SWASTA', '2017-03-06 13:32:47');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('38', '6171021508920007', 'DIDIT HARYADI', '1', 'l', 'PONTIANAK, 15 AGUSTUS 1992', 'JL. TANJUNG RAYA 1 GG.MULIA, RT/RW 001/006 KEL.DALAM BUGIS KEL.PONTIANAK TIMUR, KOTA PONTIANAK', 'JL. IMAM BONJOL NO.29, PONTIANAK', '0811560456', 'KARYAWAN SWASTA', '2017-03-06 13:36:13');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('39', '6172013112790005', 'PRIYONO PRATAMA', '1', 'l', 'NYARUNKOP, 31 DESEMBER 1979', 'JL. PAHLAWAN GG. MESJID NO.17, RT/RW 023/007 KEL.ROBAN KEC.SINGKAWANG TENGAH, KOTA SINGKAWANG', 'JL.IMAM BONJOL NO.29, PONTIANAK', '082153519220', 'WIRASWASTA', '2017-03-08 09:58:36');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('40', '6172014409910001', 'YENNI SEPTIANI', '1', 'p', 'SINGKAWANG, 04 SEPTEMBER 1991', 'JL. ANGKASA, RT/RW 017/004 KEL. ROBAN KEC. SINGKAWANG TENGAH, KOTA SINGKAWANG', 'JL. IMAM BONJOL NO.29, PONTIANAK', '085252188414', 'WIRASWASTA', '2017-03-09 13:39:03');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('41', '1402061802710001', 'TUAHMAN', '6', 'l', 'SERGEI, 18 FEBRUARI 1971', 'DUSUN SENANGKAK, RT/RW 001/001 KEL.KALON KEC.SELUAS, KABUPATEN BENGKAYANG', 'JL. IMAM BONJOL NO.29, PONTIANAK', '082351793637', 'KARYAWAN SWASTA', '2017-03-13 10:37:14');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('42', '6172012711750001', 'FAISAL KHAN', '1', 'l', 'SINGKAWANG, 27 NOVEMBER 1975', 'JL.PRAMUKA, RT/RW 006/002 KEL.CONDONG KEC.SINGKAWANG TENGAH, KOTA SINGKAWANG', 'JL.IMAM BONJOL NO.29, PONTIANAK', '085386916484', 'KARYAWAN SWASTA', '2017-03-13 10:40:49');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('43', '6171020406710010', 'SAWALUDDIN', '3', 'l', 'PONTIANAK, 4 JUNI 1971', 'JL.TJ.RAYA 1 GG.USAHA BERSAMA, RT/RW 002/005 KEL.DALAM BUGIS KEC.PONTIANAK TIMUR, KOTA PONTIANAK', 'JL. IMAM BONJOL NO.29. PONTIANAK', '0811560456', 'KARYAWAN SWASTA', '2017-03-15 11:00:10');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('44', '6171021508920007', 'DIDIT HARYADI', '1', 'l', 'PONTIANAK, 15 AGUSTUS 1992', 'JL. TANJUNG RAYA 1 GG.MULIA, RT/RW 001/006 KEL.DALAM BUGIS KEL.PONTIANAK TIMUR, KOTA PONTIANAK', 'JL. IMAM BONJOL NO.29, PONTIANAK', '0811560456', 'KARYAWAN SWASTA', '2017-03-15 11:03:11');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('45', '6171051408950008', 'ISVAN SONIA MERCY SELLY', '1', 'p', 'JAKARTA, 14 JUNI 1987', 'JL. PEMBANGUNAN NO.15, RT/RW 005/002 KEL. TENGAH KEC.SINGKAWANG BARAT, KOTA SINGKAWANG', 'JL. IMAM BONJOL NO.29, PONTIANAK', '085750333999', 'WIRASWASTA', '2017-03-17 12:02:03');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('46', '617105140895000', 'ISVAN SONIA MERCY SELLY', '1', 'p', 'JAKARTA, 14 JUNI 1987', 'JL. PEMBANGUNAN NO.15, RT/RW 005/002 KEL. TENGAH KEC.SINGKAWANG BARAT, KOTA SINGKAWANG', 'JL. IMAM BONJOL NO.29, PONTIANAK', '085750333999', 'WIRASWASTA', '2017-03-17 12:08:17');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('47', '6171051408950008', 'RIKI ANUGRAH ZULKARNAIN', '1', 'l', 'PONTIANAK, 14 AGUSTUS 1995', 'JL. RAMBUTAN NO.79, RT/RW 039/013 KEL. ROBAN KEC. SINGKAWANG TENGAH, KOTA SINGKAWANG', 'JL. IMAM BONJOL NO.29, PONTIANAK', '085246596504', 'KARYAWAN SWASTA', '2017-03-17 12:10:22');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('48', '6172010808770002', 'JUHARI', '1', 'l', 'SINGKAWANG, 08 AGUSTUS 1977', 'DUSUN PASAR LAMA RT/RW 007/001 DESA PARIT BARU KEC. SELAKAU KAB. SAMBAS', 'JL. IMAM BONJOL NO.29 , PONTIANAK', '089693332018', 'WIRASWASTA', '2017-04-21 11:14:26');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('49', '12344656', 'fani', '1', 'l', 'jakarta, 23 mei 1997', 'jl. era bary', 'jl. imam bonjo,no. 29, pontiank', '0867234566', 'karyawan swasta', '2017-05-29 11:43:22');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('50', '6172012504890002', 'YUDHIKA AFRIADI', '1', 'l', 'SINGKAWANG , 25 APRIL 1989', 'JL. CENDANA III NO. 34 PERUMNAS RT/RW 42/6 KELURAHAN ROBAN KECAMATAN SINGKAWANG TENGAH KOTA SINGKAWANG', 'JL. IMAM BONJOL NO.29, PONTIANAK', '081210726722', 'WIRASWASTA', '2017-07-24 10:04:21');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('51', '6172014403900002', 'MARYANI SAPUTRI', '1', 'p', 'PEMODIS, 04 MARET 1990', 'JL. MANGGIS RT/RW 026/009 KELURAHAN ROBAN KECAMATAN SINGKAWANG TENGAH KOTA SINGKAWANG', 'JL. IMAM BONJOL NO. 29, PONTIANAK', '089656459505', 'KARYAWAN SWASTA', '2017-07-24 10:10:42');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('52', '8205062809901834', 'ARMAN ARYAWAN SAPSUHA', '1', 'l', 'DOFA , 28 SEPTEMBER 1990', 'JL. CEMPEDAK III NO.92 RT/RW 058/006 KELURAHAN ROBAN KECAMATAN SINGKAWANG TENGAH KOTA SINGKAWANG', 'JL. IMAM BONJOL NO.29, PONTIANAK', '082255355522', 'POLRI', '2017-07-24 10:16:30');
INSERT INTO `tb_pelanggan` (`pelanggan_id`, `pelanggan_ktp`, `pelanggan_nama`, `pelanggan_agama`, `pelanggan_jk`, `pelanggan_ttl`, `pelanggan_alamat`, `pelanggan_alamat_surat`, `pelanggan_kontak`, `pelanggan_pekerjaan`, `pelanggan_datetime`) VALUES ('53', '6172010808770002', 'JUHARI', '1', 'l', 'SINGKAWANG, 08 AGUSTUS 1977', 'DUSUN PASAR LAMA RT/RW 007/001 DESA PARIT BARU KECAMATAN SELAKAU KABUPATEN SAMBAS', 'JL. IMAM BONJOL NO. 29, PONTIANAK', '089693332018', 'WIRASWASTA', '2017-07-24 10:28:09');


#
# TABLE STRUCTURE FOR: tb_penerimaan
#

DROP TABLE IF EXISTS `tb_penerimaan`;

CREATE TABLE `tb_penerimaan` (
  `penerimaan_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `penerimaan_no` varchar(30) DEFAULT NULL,
  `booking_id` bigint(20) DEFAULT NULL,
  `penerimaan_dari` varchar(255) DEFAULT NULL,
  `penerimaan_total` double(255,0) DEFAULT '0',
  `penerimaan_tanggal` date DEFAULT '0000-00-00',
  `penerimaan_uraian` varchar(255) DEFAULT NULL,
  `pkategori_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`penerimaan_id`),
  UNIQUE KEY `penerimaan_id` (`penerimaan_id`),
  KEY `p_bookingid_fk` (`booking_id`),
  KEY `p_pkategori_fk` (`pkategori_id`),
  CONSTRAINT `p_bookingid_fk` FOREIGN KEY (`booking_id`) REFERENCES `tb_booking` (`booking_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `p_pkategori_fk` FOREIGN KEY (`pkategori_id`) REFERENCES `penerimaan_kategori` (`pkategori_id`)
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=latin1;

INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('2', '', '2', 'NADIA SEPTIANTI', '500000', '2017-03-05', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('3', '', '3', 'JENNIFER YOHANA, F.S', '500000', '2017-03-05', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('4', '', '4', 'SUSBIYATNO', '500000', '2017-03-05', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('5', 'HR2-C06/001-001/060317', '2', 'NADIA SEPTIANTI', '1000000', '2016-12-14', 'Pembayaran ke 1', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('6', '', '5', 'SUBHAN', '500000', '2017-03-06', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('7', '', '6', 'TRIYANDI KESATRIA ANUGRAH', '500000', '2017-03-06', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('9', '', '8', 'RUDI HENDRIKO DAMANIK', '500000', '2017-03-06', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('10', '', '9', 'TOMMY SEPTIAN', '500000', '2017-03-06', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('11', '', '10', 'ADE IRMASARI', '500000', '2017-03-06', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('12', '', '11', 'RIZA SUSANTI', '500000', '2017-03-06', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('13', '', '12', 'YOLANDA AFRICIA MAMPUK', '500000', '2017-03-06', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('15', '', '14', 'DEBI JULIANDI', '500000', '2017-03-06', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('16', '', '15', 'ELVRYDA MARTHA LENA S. S.SOS', '500000', '2017-03-06', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('18', '', '17', 'ANDIKA ADINATA', '500000', '2017-03-06', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('19', '', '18', 'ANDI PRAMONO', '500000', '2017-03-06', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('20', '', '19', 'LEGIANA', '500000', '2017-03-06', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('21', '', '20', 'LIZA WATI', '500000', '2017-03-06', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('23', '', '22', 'VELLEN WIBOWO', '500000', '2017-03-06', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('24', '', '23', 'VELLIKA WIBOWO', '500000', '2017-03-06', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('27', '', '26', 'MUHAMMAD', '500000', '2017-03-06', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('28', '', '27', 'RUSDIMAN', '500000', '2017-03-06', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('30', 'HR2-C08/002-001/070317', '3', 'JENNIFER YOHANA, F.S', '5000000', '2016-12-21', 'Pembayaran ke 1', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('31', 'HR2-C09/003-001/070317', '4', 'SUSBIYATNO', '1000000', '2016-12-24', 'Pembayaran ke 1', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('32', 'HR2-C09/003-002/070317', '4', 'SUSBIYATNO', '1000000', '2017-02-01', 'Pembayaran ke 2', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('33', 'HR2-C11/010-001/070317', '11', 'RIZA SUSANTI', '3000000', '2016-12-20', 'Pembayaran ke 1', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('34', 'HR2-C11/010-002/070317', '11', 'RIZA SUSANTI', '3000000', '2017-01-18', 'Pembayaran ke 2', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('35', 'HR2-C12/005-001/070317', '6', 'TRIYANDI KESATRIA ANUGRAH', '1000000', '2016-12-27', 'Pembayaran ke 1', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('36', 'HR2-C13/012-001/070317', '14', 'DEBI JULIANDI', '1000000', '2016-12-29', 'Pembayaran ke 1', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('37', 'HR2-C13/012-002/070317', '14', 'DEBI JULIANDI', '1000000', '2017-01-24', 'Pembayaran ke 2', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('38', 'HR2-C18/011-001/070317', '12', 'YOLANDA AFRICIA MAMPUK', '1000000', '2016-12-27', 'Pembayaran ke 1', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('39', 'HR2-C18/011-002/070317', '12', 'YOLANDA AFRICIA MAMPUK', '1000000', '2017-02-28', 'Pembayaran ke 2', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('40', 'HR2-D04/014-001/070317', '17', 'ANDIKA ADINATA', '1000000', '2016-12-23', 'Pembayaran ke 1', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('41', 'HR2-D04/014-002/070317', '17', 'ANDIKA ADINATA', '1000000', '2017-02-06', 'Pembayaran ke 2', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('46', 'HR2-D09/009-001/070317', '10', 'ADE IRMASARI', '1000000', '2016-12-24', 'Pembayaran ke 1', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('47', 'HR2-D10/015-001/070317', '18', 'ANDI PRAMONO', '2000000', '2016-12-30', 'Pembayaran ke 1', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('48', 'HR2-D11/013-001/070317', '15', 'ELVRYDA MARTHA LENA S. S.SOS', '800000', '2016-12-29', 'Pembayaran ke 1', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('49', 'HR2-D11/013-002/070317', '15', 'ELVRYDA MARTHA LENA S. S.SOS', '1200000', '2017-02-01', 'Pembayaran ke 2', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('50', 'HR2-D11/013-003/070317', '15', 'ELVRYDA MARTHA LENA S. S.SOS', '1500000', '2017-03-02', 'Pembayaran ke 3', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('51', 'HR2-D12/008-001/070317', '9', 'TOMMY SEPTIAN', '1000000', '2016-12-30', 'Pembayaran ke 1', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('54', '', '29', 'PRIYONO PRATAMA', '500000', '2017-03-08', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('55', '', '30', 'YENNI SEPTIANI', '500000', '2017-03-09', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('56', 'HR2-D05/008-001/090317', '29', 'PRIYONO PRATAMA', '2000000', '2016-11-23', 'Pembayaran ke 1', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('57', 'HR2-D05/008-002/090317', '29', 'PRIYONO PRATAMA', '2000000', '2016-12-02', 'Pembayaran ke 2', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('58', 'HR2-D05/008-003/090317', '29', 'PRIYONO PRATAMA', '2000000', '2016-12-27', 'Pembayaran ke 3', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('59', 'HR2-D05/008-004/090317', '29', 'PRIYONO PRATAMA', '2000000', '2017-01-24', 'Pembayaran ke 4', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('60', 'HR2-C05/016-001/100317', '19', 'LEGIANA', '1000000', '2017-03-10', 'Pembayaran ke 1', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('61', 'HR2-C18/011-003/130317', '12', 'YOLANDA AFRICIA MAMPUK', '1000000', '2017-03-11', 'Pembayaran ke 3', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('62', 'HR2-D17/007-001/130317', '8', 'RUDI HENDRIKO DAMANIK', '1000000', '2016-12-30', 'Pembayaran ke 1', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('63', 'HR2-D17/007-002/130317', '8', 'RUDI HENDRIKO DAMANIK', '1000000', '2017-03-11', 'Pembayaran ke 2', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('64', 'HR2-C10/004-001/130317', '5', 'SUBHAN', '1000000', '2017-03-10', 'Pembayaran ke 1', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('65', '', '31', 'TUAHMAN', '500000', '2017-03-13', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('66', '', '32', 'FAISAL KHAN', '500000', '2017-03-13', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('67', 'HR2-D14/008-001/130317', '31', 'TUAHMAN', '1000000', '2016-12-30', 'Pembayaran ke 1', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('68', 'HR2-D14/008-002/130317', '31', 'TUAHMAN', '1000000', '2017-03-11', 'Pembayaran ke 2', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('69', '', '33', 'SAWALUDDIN', '500000', '2017-03-15', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('70', '', '34', 'DIDIT HARYADI', '500000', '2017-03-15', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('71', 'HR1-C18/010-001/170317', '33', 'SAWALUDDIN', '14000000', '2017-03-16', 'Pembayaran ke 1', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('72', 'HR1-D01/003-001/170317', '22', 'VELLEN WIBOWO', '20000000', '2017-03-16', 'Pembayaran ke 1', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('73', 'HR1-D02/004-001/170317', '23', 'VELLIKA WIBOWO', '15000000', '2017-03-16', 'Pembayaran ke 1', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('74', 'HR1-D03/007-002/170317', '26', 'MUHAMMAD', '7000000', '2017-03-16', 'Pembayaran ke 1', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('75', 'HR1-D04/008-001/170317', '27', 'RUSDIMAN', '7000000', '2017-03-16', 'Pembayaran ke 1', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('76', 'HR1-D18/010-001/170317', '34', 'DIDIT HARYADI', '12000000', '2017-03-16', 'Pembayaran ke 1', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('78', '', '36', 'ISVAN SONIA MERCY SELLY', '500000', '2017-03-17', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('80', 'HR1-D05/011-001/170317', '36', 'ISVAN SONIA MERCY SELLY', '5000000', '2016-12-27', 'Pembayaran ke 1', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('82', 'HR2-C06/001-002/290317', '2', 'NADIA SEPTIANTI', '5000000', '2017-03-29', 'Pembayaran ke 2', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('84', 'HR2-C08/002-002/030417', '3', 'JENNIFER YOHANA, F.S', '5000000', '2017-04-03', 'Pembayaran ke 2', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('85', 'HR2-D11/013-004/030417', '15', 'ELVRYDA MARTHA LENA S. S.SOS', '1500000', '2017-04-03', 'Pembayaran ke 4', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('86', 'HR1-C05/001-001/030417', '20', 'LIZA WATI', '10000000', '2017-04-03', 'Pembayaran ke 1', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('87', 'HR2-C05/016-002/080417', '19', 'LEGIANA', '5000000', '2017-04-08', 'Pembayaran ke 2', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('88', 'HR2-C10/004-002/110417', '5', 'SUBHAN', '2000000', '2017-04-11', 'Pembayaran ke 2', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('91', 'HR2-D17/007-003/250417', '8', 'RUDI HENDRIKO DAMANIK', '6000000', '2017-04-25', 'Pembayaran ke 3', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('92', 'HR2-D11/013-005/290417', '15', 'ELVRYDA MARTHA LENA S. S.SOS', '1500000', '2017-04-29', 'Pembayaran ke 5', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('93', 'HR2-D16/008-001/040517', '32', 'FAISAL KHAN', '2000000', '2016-12-30', 'Pembayaran ke 1', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('94', 'HR2-D09/009-002/060517', '10', 'ADE IRMASARI', '7000000', '2017-05-06', 'Pembayaran ke 2', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('95', 'HR2-C10/004-003/080517', '5', 'SUBHAN', '1000000', '2017-05-08', 'Pembayaran ke 3', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('96', 'HR2-D16/008-002/090517', '32', 'FAISAL KHAN', '1000000', '2017-05-09', 'Pembayaran ke 2', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('98', 'HR2-C05/016-003/150517', '19', 'LEGIANA', '10000000', '2017-05-15', 'Pembayaran ke 3', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('100', 'HR2-C13/012-003/300517', '14', 'DEBI JULIANDI', '1000000', '2017-05-30', 'Pembayaran ke 3', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('101', 'HR2-D11/013-006/310517', '15', 'ELVRYDA MARTHA LENA S. S.SOS', '1500000', '2017-05-31', 'Pembayaran ke 6', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('102', 'HR2-D16/008-003/140617', '32', 'FAISAL KHAN', '1000000', '2017-06-14', 'Pembayaran ke 3', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('103', 'HR2-C10/004-004/110717', '5', 'SUBHAN', '2000000', '2017-07-11', 'Pembayaran ke 4', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('104', 'HR1-D03/007-003/190717', '26', 'MUHAMMAD', '7000000', '2017-07-19', 'Pembayaran ke 2', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('105', '', '40', 'YUDHIKA AFRIADI', '500000', '2017-07-24', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('106', '', '41', 'MARYANI SAPUTRI', '500000', '2017-07-24', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('107', '', '42', 'ARMAN ARYAWAN SAPSUHA', '500000', '2017-07-24', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('108', '', '43', 'JUHARI', '500000', '2017-07-24', 'Tanda Jadi', '1');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('109', 'HR1-C05/001-002/290717', '20', 'LIZA WATI', '96790000', '2017-07-29', 'Pencairan Induk', '2');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('110', 'HR1-C18/010-002/290717', '33', 'SAWALUDDIN', '108770000', '2017-07-29', 'Pencairan Induk', '2');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('111', 'HR1-D03/007-004/290717', '26', 'MUHAMMAD', '102430000', '2017-07-29', 'Pencairan Induk', '2');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('113', 'HR1-D04/008-002/290717', '27', 'RUSDIMAN', '108770000', '2017-07-29', 'Pencairan Induk', '2');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('114', 'HR1-D05/011-002/290717', '36', 'ISVAN SONIA MERCY SELLY', '104310000', '2017-07-29', 'Pencairan Induk', '2');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('115', 'HR1-D06/011-001/290717', '43', 'JUHARI', '113270000', '2017-07-29', 'Pencairan Induk', '2');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('116', 'HR1-D18/010-002/290717', '34', 'DIDIT HARYADI', '109010000', '2017-07-29', 'Pencairan Induk', '2');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('117', 'HR1-D06/011-002/310717', '43', 'JUHARI', '3000000', '2017-07-31', 'Pembayaran ke 1', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('118', 'HR1-C05/001-003/050817', '20', 'LIZA WATI', '7000000', '2017-08-05', 'Pembayaran ke 2', '3');
INSERT INTO `tb_penerimaan` (`penerimaan_id`, `penerimaan_no`, `booking_id`, `penerimaan_dari`, `penerimaan_total`, `penerimaan_tanggal`, `penerimaan_uraian`, `pkategori_id`) VALUES ('119', 'HR2-D16/008-004/050817', '32', 'FAISAL KHAN', '1000000', '2017-08-05', 'Pembayaran ke 4', '3');


#
# TABLE STRUCTURE FOR: tb_pengeluaran
#

DROP TABLE IF EXISTS `tb_pengeluaran`;

CREATE TABLE `tb_pengeluaran` (
  `pengeluaran_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pengeluaran_no` varchar(30) DEFAULT NULL,
  `pengeluaran_kepada` varchar(255) DEFAULT NULL,
  `pengeluaran_volume` double(255,0) DEFAULT '0',
  `pengeluaran_satuan` varchar(20) DEFAULT NULL,
  `pengeluaran_harga_satuan` double(255,0) DEFAULT '0',
  `pengeluaran_total` double(255,0) DEFAULT '0',
  `pengeluaran_tanggal` date DEFAULT '0000-00-00',
  `pp_id` bigint(20) DEFAULT NULL,
  `pj_id` bigint(20) DEFAULT NULL,
  `rumah_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`pengeluaran_id`),
  UNIQUE KEY `pengeluaran_id` (`pengeluaran_id`),
  KEY `pp_ppid_fk` (`pp_id`),
  KEY `pp_pjid_fk` (`pj_id`),
  KEY `pp_rumahid_fk` (`rumah_id`),
  CONSTRAINT `pp_pjid_fk` FOREIGN KEY (`pj_id`) REFERENCES `pengeluaran_jenis` (`pj_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pp_ppid_fk` FOREIGN KEY (`pp_id`) REFERENCES `pengeluaran_kategori` (`pp_id`),
  CONSTRAINT `pp_rumahid_fk` FOREIGN KEY (`rumah_id`) REFERENCES `tb_rumah` (`rumah_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=latin1;

INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('4', 'HR2/P/001/130317', 'Uray Yusi Mandela', '12', 'Unit', '2000000', '24000000', '2017-03-13', '25', '4', '2');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('5', 'HR1/P/001/140317', 'CHALID RAZALVI', '3', 'Unit', '57500000', '172500000', '2017-03-14', '33', '5', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('6', 'HR1/P/001/170317', 'VILAND PROPERTY', '6', 'Bulan', '5000000', '30000000', '2017-03-17', '58', '7', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('8', 'HR2/P/003/170317', 'VILAND PROPERTY', '6', 'Bulan', '5000000', '30000000', '2017-03-17', '58', '7', '2');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('9', 'HR1/P/002/220317', 'SUB-KONTRAKTOR', '1', 'LS', '30500000', '30500000', '2017-03-22', '27', '4', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('10', 'HR2/P/001/220317', 'ABDURRAHMAN', '1', 'LS', '50000000', '50000000', '2017-03-22', '13', '1', '2');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('12', 'HR2/P/001/220317', 'KECAMATAN SINGKAWANG TENGAH', '1', 'LS', '1600000', '1600000', '2017-03-22', '18', '3', '2');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('13', 'HR1/P/002/240317', '', '1', 'LS', '450000', '450000', '2017-03-24', '27', '4', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('14', 'HR1/P/004/250317', '', '1', 'LS', '500000', '500000', '2017-03-25', '68', '7', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('15', 'HR2/P/002/290317', '', '1', 'LS', '3000000', '3000000', '2017-03-29', '23', '3', '2');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('16', 'HR1/P/004/070417', '', '0', '', '0', '0', '2017-04-07', '69', '7', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('17', 'HR1/P/004/070417', 'RISKA', '1', 'LS', '5000000', '5000000', '2017-04-07', '69', '7', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('19', 'HR2/P/003/080417', 'BNI', '1', 'LS', '590000', '590000', '2017-04-07', '23', '3', '2');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('20', 'HR2/P/004/080417', 'OM WALID', '1', 'LS', '2500000', '2500000', '2017-04-08', '23', '3', '2');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('21', 'HR2/P/002/110417', 'SUROTO', '1', 'LS', '10000000', '10000000', '2017-04-10', '32', '4', '2');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('22', 'HR2/P/003/300617', 'ALDI', '1', 'UNIT', '62500000', '62500000', '2017-04-21', '5', '2', '2');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('23', 'HR2/P/003/030517', 'ALDI', '1', 'UNIT', '62500000', '62500000', '2017-05-02', '33', '5', '2');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('24', 'HR2/P/001/030517', 'CHALID RAZALVI', '1', 'LS', '10000000', '10000000', '2017-05-02', '70', '6', '2');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('25', 'HR1/P/002/030517', 'CHALID RAZALVI', '1', 'LS', '10000000', '10000000', '2017-05-03', '70', '6', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('26', 'HR1/P/004/030517', 'UTIN', '1', 'LS', '5000000', '5000000', '2017-05-03', '58', '7', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('27', 'HR1/P/001/120517', 'JAHOTMAN', '1', 'Ls', '29100000', '29100000', '2017-05-12', '74', '8', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('29', 'HR3/P/002/120517', 'MARTABUN', '1', 'Ls', '50000000', '50000000', '2017-05-12', '13', '1', '5');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('30', 'HR3/P/003/120517', 'HERI', '1', 'Ls', '2000000', '2000000', '2017-05-12', '77', '1', '5');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('31', 'HR3/P/004/120517', 'TOMI', '1', 'Ls', '4000000', '4000000', '2017-05-12', '68', '7', '5');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('32', 'HR1/P/002/120517', 'MANDELA', '1', 'Ls', '10000000', '10000000', '2017-05-12', '70', '6', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('33', 'HR1/P/002/120517', 'BANK BTN', '1', 'Ls', '28000000', '28000000', '2017-05-12', '76', '8', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('34', 'HR2/P/002/120517', 'MANDELA', '1', 'Ls', '10000000', '10000000', '2017-05-12', '70', '6', '2');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('35', 'HR1/P/003/150517', 'YUDHIKA', '1', 'LS', '1500000', '1500000', '2017-05-15', '38', '6', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('36', 'HR2/P/003/150517', 'YUDHIKA', '1', 'LS', '1500000', '1500000', '2017-05-15', '38', '6', '2');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('37', 'HR1/P/001/150517', 'REINALDI', '1', 'LS', '25000000', '25000000', '2017-05-15', '7', '2', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('38', 'HR1/P/004/170517', 'CHALID RAZALVI', '1', 'LS', '5000000', '5000000', '2017-05-17', '70', '6', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('39', 'HR2/P/004/170517', 'CHALID RAZALVI', '1', 'LS', '5000000', '5000000', '2017-05-17', '70', '6', '2');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('40', 'HR3/P/005/180517', 'TOMMY', '1', 'Ls', '2000000', '2000000', '2017-05-18', '68', '7', '5');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('41', 'HR3/P/006/200517', 'TOMI', '1', 'LS', '4000000', '4000000', '2017-05-20', '68', '7', '5');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('42', 'HR1/P/003/220517', 'SUROTO', '37', 'Unit', '65000', '2405000', '2017-05-22', '78', '4', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('43', 'HR1/P/004/290517', 'ALDI', '3', 'UNIT', '57500000', '172500000', '2017-05-29', '33', '5', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('44', 'HR1/P/002/290517', 'ALDI', '1', 'LS', '20405000', '20405000', '2017-05-29', '7', '2', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('45', 'HR1/P/007/290517', 'UTIN', '1', 'LS', '5000000', '5000000', '2017-05-29', '58', '7', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('46', 'HR1/P/007/290517', 'H.URAY SUTAMSI', '1', 'LS', '50000000', '50000000', '2017-05-29', '58', '7', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('47', 'HR3/P/005/300517', 'YUDHIKA AFRIADI', '2000', 'LEMBAR', '1490', '2980000', '2017-05-30', '37', '6', '5');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('48', 'HR1/P/006/310517', 'YUDHIKA', '10', 'LS', '155000', '1550000', '2017-05-31', '39', '6', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('49', 'HR1/P/006/310517', 'YUDHIKA', '1', 'LA', '200000', '200000', '2017-05-31', '39', '6', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('50', 'HR1/P/006/310517', 'URAY YUSI MANDELA', '1', 'LS', '10000000', '10000000', '2017-05-31', '70', '6', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('51', 'HR2/P/006/310517', 'URAY YUSI MANDELA', '1', 'LS', '10000000', '10000000', '2017-05-31', '70', '6', '2');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('52', 'HR2/P/005/310517', 'ARI PENANAMAN MODAL', '1', 'LS', '1700000', '1700000', '2017-05-31', '19', '3', '2');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('53', 'HR1/P/007/020617', 'UTIN', '1', 'LS', '10000000', '10000000', '2017-06-02', '58', '7', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('54', 'HR2/P/007/020617', 'UTIN', '1', 'LS', '20000000', '20000000', '2017-06-02', '58', '7', '2');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('55', 'HR2/P/007/050617', '', '1', 'LS', '6500000', '6500000', '2017-06-05', '69', '7', '2');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('56', 'HR2/P/004/070617', 'ALDI', '1', 'UNIT', '62500000', '62500000', '2017-06-07', '33', '5', '2');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('57', 'HR1/P/007/070617', 'DELLA & RAVI', '1', 'LS', '20000000', '20000000', '2017-06-07', '59', '7', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('59', 'HR1/P/003/140617', 'BANG DWI', '1', 'LS', '25000000', '25000000', '2017-06-14', '66', '8', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('60', 'HR3/P/006/170617', 'GUSTI', '1', 'LS', '2500000', '2500000', '2017-06-17', '23', '3', '5');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('61', 'HR1/P/007/300617', 'VILAND PROPERTY', '1', 'Bulan', '5000000', '5000000', '2017-06-30', '58', '7', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('62', 'HR2/P/005/300617', 'ALDI', '2', 'UNIT', '62500000', '125000000', '2017-06-30', '33', '5', '2');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('63', 'HR2/P/007/300617', 'PU-PR', '1', 'LS', '5000000', '5000000', '2017-06-30', '20', '3', '2');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('64', 'HR1/P/006/300617', 'ALDI', '3', 'UNIT', '57500000', '172500000', '2017-06-30', '33', '5', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('65', 'HR1/P/004/030717', 'BANG DWI', '1', 'LS', '10000000', '10000000', '2017-07-03', '66', '8', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('66', 'HR1/P/007/040717', 'VILAND PROPERTY', '1', 'BULAN', '5000000', '5000000', '2017-07-04', '58', '7', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('67', 'HR2/P/007/040717', 'VILAND PROPERTY', '1', 'BULAN', '5000000', '5000000', '2017-07-04', '58', '7', '2');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('68', 'HR1/P/003/060717', 'GUNTUR', '1', 'LS', '1000000', '1000000', '2017-07-06', '79', '4', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('69', 'HR1/P/006/110717', 'YUDHIKA', '4', 'RIM', '745000', '2980000', '2017-07-11', '37', '6', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('70', 'HR2/P/006/110717', 'YUDHIKA', '4', 'RIM', '745000', '2980000', '2017-07-11', '37', '6', '2');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('71', 'HR3/P/007/200717', 'GUSTI GANDI', '1', 'LS', '5000000', '5000000', '2017-07-20', '23', '3', '5');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('72', 'HR1/P/006/200717', 'AANK', '1', '', '2304000', '2304000', '2017-07-20', '41', '6', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('73', 'HR2/P/006/290717', 'ALDI', '1', 'UNIT', '62500000', '62500000', '2017-04-21', '33', '5', '2');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('74', 'HR1/P/007/290717', 'UTIN', '7', 'UNIT', '500000', '3500000', '2017-07-29', '52', '7', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('75', 'HR1/P/007/290717', 'FANI', '7', 'UNIT', '500000', '3500000', '2017-07-29', '54', '7', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('76', 'HR1/P/007/290717', 'RAVI', '7', 'UNIT', '500000', '3500000', '2017-07-29', '48', '7', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('77', 'HR1/P/007/290717', 'DELLA', '7', 'UNIT', '500000', '3500000', '2017-07-29', '51', '7', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('78', 'HR1/P/007/290717', 'FRANS', '7', 'UNIT', '500000', '3500000', '2017-07-29', '53', '7', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('79', 'HR1/P/007/290717', 'WIBOWO', '4', 'UNIT', '500000', '2000000', '2017-07-29', '57', '7', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('81', 'HR1/P/007/290717', 'FRANS', '2', 'UNIT', '500000', '1000000', '2017-07-29', '57', '7', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('82', 'HR1/P/007/290717', 'VILAND', '1', 'UNIT', '500000', '500000', '2017-07-29', '57', '7', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('83', 'HR1/P/007/290717', 'ROVI', '7', 'UNIT', '500000', '3500000', '2017-07-29', '55', '7', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('84', 'HR1/P/007/290717', 'DIMAS', '7', 'UNIT', '500000', '3500000', '2017-07-29', '56', '7', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('85', 'HR1/P/007/290717', 'REI DAN VILAND', '1', 'LS', '5000000', '5000000', '2017-07-29', '58', '7', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('87', 'HR2/P/007/310717', 'ALDI', '4', 'UNIT', '62500000', '250000000', '2017-07-31', '33', '5', '2');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('88', 'HR1/P/008/310717', 'OM WALID', '1', 'LS', '25000000', '25000000', '2017-07-31', '22', '3', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('89', 'HR3/P/004/310717', 'MARTABUN', '1', 'LS', '5000000', '5000000', '2017-07-31', '13', '1', '5');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('90', 'HR1/P/007/010817', 'UTIN', '1', 'BULAN', '9500000', '9500000', '2017-08-01', '69', '7', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('91', 'HR2/P/004/100817', 'UTIN', '1', 'BULAN', '9450000', '9450000', '2017-08-01', '5', '2', '2');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('92', 'HR2/P/008/070817', 'DWI', '1', 'LS', '500000', '500000', '2017-08-07', '15', '3', '2');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('93', 'HR1/P/006/100817', 'FRANSISKUS ( HOM 1,2,3 )', '1', 'LS', '500000', '500000', '2017-08-10', '46', '6', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('96', 'HR1/P/007/100817', 'UTIN', '1', 'BULAN', '9450000', '9450000', '2017-08-10', '58', '7', '1');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('97', 'HR2/P/007/100817', 'UTIN', '1', 'BULAN', '9450000', '9450000', '2017-08-10', '58', '7', '2');
INSERT INTO `tb_pengeluaran` (`pengeluaran_id`, `pengeluaran_no`, `pengeluaran_kepada`, `pengeluaran_volume`, `pengeluaran_satuan`, `pengeluaran_harga_satuan`, `pengeluaran_total`, `pengeluaran_tanggal`, `pp_id`, `pj_id`, `rumah_id`) VALUES ('98', 'HR1/P/007/100817', 'UTIN ( AJB AN ISVAN SONIA MERCY D05 )', '1', 'UNIT', '1500000', '1500000', '2017-08-10', '58', '7', '1');


#
# TABLE STRUCTURE FOR: tb_ppjb
#

DROP TABLE IF EXISTS `tb_ppjb`;

CREATE TABLE `tb_ppjb` (
  `ppjb_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ppjb_no` varchar(30) DEFAULT NULL,
  `booking_id` bigint(20) DEFAULT NULL,
  `ppjb_status` enum('y','n') DEFAULT 'n',
  `ppjb_date` date DEFAULT '0000-00-00',
  PRIMARY KEY (`ppjb_id`),
  KEY `tbppjb_bookingid_fk` (`booking_id`) USING BTREE,
  CONSTRAINT `tbppjb_bookingid_fk` FOREIGN KEY (`booking_id`) REFERENCES `tb_booking` (`booking_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

INSERT INTO `tb_ppjb` (`ppjb_id`, `ppjb_no`, `booking_id`, `ppjb_status`, `ppjb_date`) VALUES ('1', '001/HR1-C05/150317', '20', 'y', '2017-03-15');
INSERT INTO `tb_ppjb` (`ppjb_id`, `ppjb_no`, `booking_id`, `ppjb_status`, `ppjb_date`) VALUES ('2', '001/HR1-C18/150317', '33', 'y', '2017-03-15');
INSERT INTO `tb_ppjb` (`ppjb_id`, `ppjb_no`, `booking_id`, `ppjb_status`, `ppjb_date`) VALUES ('3', '001/HR1-D01/150317', '22', 'y', '0000-00-00');
INSERT INTO `tb_ppjb` (`ppjb_id`, `ppjb_no`, `booking_id`, `ppjb_status`, `ppjb_date`) VALUES ('4', '001/HR1-D02/150317', '23', 'y', '2017-03-15');
INSERT INTO `tb_ppjb` (`ppjb_id`, `ppjb_no`, `booking_id`, `ppjb_status`, `ppjb_date`) VALUES ('5', '001/HR1-D05/180317', '36', 'y', '0000-00-00');
INSERT INTO `tb_ppjb` (`ppjb_id`, `ppjb_no`, `booking_id`, `ppjb_status`, `ppjb_date`) VALUES ('6', '001/HR1-D03/120517', '26', 'y', '0000-00-00');
INSERT INTO `tb_ppjb` (`ppjb_id`, `ppjb_no`, `booking_id`, `ppjb_status`, `ppjb_date`) VALUES ('7', '001/HR1-D04/120517', '27', 'y', '0000-00-00');
INSERT INTO `tb_ppjb` (`ppjb_id`, `ppjb_no`, `booking_id`, `ppjb_status`, `ppjb_date`) VALUES ('8', '001/HR1-D18/240717', '34', 'y', '0000-00-00');
INSERT INTO `tb_ppjb` (`ppjb_id`, `ppjb_no`, `booking_id`, `ppjb_status`, `ppjb_date`) VALUES ('9', '001/HR1-D06/240717', '43', 'y', '0000-00-00');


#
# TABLE STRUCTURE FOR: tb_rumah
#

DROP TABLE IF EXISTS `tb_rumah`;

CREATE TABLE `tb_rumah` (
  `rumah_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `rumah_nama` varchar(255) DEFAULT NULL,
  `rumah_alamat` text,
  `rumah_created` datetime DEFAULT '0000-00-00 00:00:00',
  `rumah_provinsi` varchar(255) DEFAULT NULL,
  `rumah_kota` varchar(255) DEFAULT NULL,
  `rumah_kecamatan` varchar(255) DEFAULT NULL,
  `rumah_desa` varchar(255) DEFAULT NULL,
  `rumah_kode` varchar(50) DEFAULT NULL,
  `modal_awal` double(255,0) DEFAULT '0',
  PRIMARY KEY (`rumah_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `tb_rumah` (`rumah_id`, `rumah_nama`, `rumah_alamat`, `rumah_created`, `rumah_provinsi`, `rumah_kota`, `rumah_kecamatan`, `rumah_desa`, `rumah_kode`, `modal_awal`) VALUES ('1', 'HOMENESTY RESIDENCE 1', 'Jalan Ratu Sepudak - Gg. M. Saad', '2016-10-13 16:39:51', 'Kalimantan Barat', 'Singkawang', 'Singkawang Utara', 'Sungai Rasau', 'HR1', '1011000000');
INSERT INTO `tb_rumah` (`rumah_id`, `rumah_nama`, `rumah_alamat`, `rumah_created`, `rumah_provinsi`, `rumah_kota`, `rumah_kecamatan`, `rumah_desa`, `rumah_kode`, `modal_awal`) VALUES ('2', 'HOMENESTY RESIDENCE 2', 'Jalan Wonosari', '2016-10-13 16:40:53', 'Kalimantan Barat', 'Singkawang', 'Singkawang Tengah', 'Roban', 'HR2', '350000000');
INSERT INTO `tb_rumah` (`rumah_id`, `rumah_nama`, `rumah_alamat`, `rumah_created`, `rumah_provinsi`, `rumah_kota`, `rumah_kecamatan`, `rumah_desa`, `rumah_kode`, `modal_awal`) VALUES ('3', 'THE RAFFLESIA', 'Jalan Alianyang - Gg. Harapan', '2016-10-13 16:42:13', 'Kalimantan Barat', 'Singkawang', 'Singkawang Tengah', 'Jawa', 'TR', '0');
INSERT INTO `tb_rumah` (`rumah_id`, `rumah_nama`, `rumah_alamat`, `rumah_created`, `rumah_provinsi`, `rumah_kota`, `rumah_kecamatan`, `rumah_desa`, `rumah_kode`, `modal_awal`) VALUES ('4', 'GREENLAND RESIDENCE', 'Jalan Semai', '2016-10-13 16:43:22', 'Kalimantan Barat', 'Singkawang', 'Singkawang Utara', 'Sungai Garam Hilir', 'GR', '0');
INSERT INTO `tb_rumah` (`rumah_id`, `rumah_nama`, `rumah_alamat`, `rumah_created`, `rumah_provinsi`, `rumah_kota`, `rumah_kecamatan`, `rumah_desa`, `rumah_kode`, `modal_awal`) VALUES ('5', 'Homenesty Residence 3', 'Jalan Gayung Bersambaut', '2017-05-04 19:05:18', 'Kalimantan Barat', 'Singkawang', 'Singkawang Utara', 'Setapuk Kecil', 'HR3', '65000000');


#
# TABLE STRUCTURE FOR: tb_skr
#

DROP TABLE IF EXISTS `tb_skr`;

CREATE TABLE `tb_skr` (
  `skr_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `booking_id` bigint(20) DEFAULT NULL,
  `skr_status` enum('n','y') DEFAULT 'n',
  `skr_date` date DEFAULT '0000-00-00',
  PRIMARY KEY (`skr_id`),
  KEY `skr_bookingid_fk` (`booking_id`),
  CONSTRAINT `skr_bookingid_fk` FOREIGN KEY (`booking_id`) REFERENCES `tb_booking` (`booking_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tb_sp3k
#

DROP TABLE IF EXISTS `tb_sp3k`;

CREATE TABLE `tb_sp3k` (
  `sp3k_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `booking_id` bigint(20) DEFAULT NULL,
  `sp3k_status` enum('y','n') DEFAULT 'n',
  `sp3k_date` date DEFAULT '0000-00-00',
  `sp3k_no` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`sp3k_id`),
  KEY `tbsp3k_bookingid_fk` (`booking_id`) USING BTREE,
  CONSTRAINT `tbsp3k_bookingid_fk` FOREIGN KEY (`booking_id`) REFERENCES `tb_booking` (`booking_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO `tb_sp3k` (`sp3k_id`, `booking_id`, `sp3k_status`, `sp3k_date`, `sp3k_no`) VALUES ('1', '20', 'y', '0000-00-00', '');
INSERT INTO `tb_sp3k` (`sp3k_id`, `booking_id`, `sp3k_status`, `sp3k_date`, `sp3k_no`) VALUES ('2', '33', 'y', '0000-00-00', '');
INSERT INTO `tb_sp3k` (`sp3k_id`, `booking_id`, `sp3k_status`, `sp3k_date`, `sp3k_no`) VALUES ('3', '23', 'y', '0000-00-00', '');
INSERT INTO `tb_sp3k` (`sp3k_id`, `booking_id`, `sp3k_status`, `sp3k_date`, `sp3k_no`) VALUES ('4', '26', 'y', '0000-00-00', '');
INSERT INTO `tb_sp3k` (`sp3k_id`, `booking_id`, `sp3k_status`, `sp3k_date`, `sp3k_no`) VALUES ('5', '27', 'y', '0000-00-00', '');
INSERT INTO `tb_sp3k` (`sp3k_id`, `booking_id`, `sp3k_status`, `sp3k_date`, `sp3k_no`) VALUES ('6', '36', 'y', '0000-00-00', '');
INSERT INTO `tb_sp3k` (`sp3k_id`, `booking_id`, `sp3k_status`, `sp3k_date`, `sp3k_no`) VALUES ('7', '43', 'y', '0000-00-00', '');
INSERT INTO `tb_sp3k` (`sp3k_id`, `booking_id`, `sp3k_status`, `sp3k_date`, `sp3k_no`) VALUES ('8', '34', 'y', '0000-00-00', '');
INSERT INTO `tb_sp3k` (`sp3k_id`, `booking_id`, `sp3k_status`, `sp3k_date`, `sp3k_no`) VALUES ('9', '19', 'y', '2017-04-25', 'e0668/00042/SP3K/IV/2017');
INSERT INTO `tb_sp3k` (`sp3k_id`, `booking_id`, `sp3k_status`, `sp3k_date`, `sp3k_no`) VALUES ('10', '40', 'y', '2017-07-19', 'e0302/00042/SP3K/VII/2017');
INSERT INTO `tb_sp3k` (`sp3k_id`, `booking_id`, `sp3k_status`, `sp3k_date`, `sp3k_no`) VALUES ('11', '3', 'y', '2017-04-25', 'e0646/00042/SP3K/IV/2017');
INSERT INTO `tb_sp3k` (`sp3k_id`, `booking_id`, `sp3k_status`, `sp3k_date`, `sp3k_no`) VALUES ('12', '5', 'y', '2017-04-25', 'e0666/00042/SP3K/IV/2017');
INSERT INTO `tb_sp3k` (`sp3k_id`, `booking_id`, `sp3k_status`, `sp3k_date`, `sp3k_no`) VALUES ('13', '14', 'y', '2017-04-25', 'e0667/00042/SP3K/IV/2017');
INSERT INTO `tb_sp3k` (`sp3k_id`, `booking_id`, `sp3k_status`, `sp3k_date`, `sp3k_no`) VALUES ('14', '32', 'y', '2017-04-25', 'e0665/00042/SP3K/IV/2017');


#
# TABLE STRUCTURE FOR: tb_user
#

DROP TABLE IF EXISTS `tb_user`;

CREATE TABLE `tb_user` (
  `user_id` int(20) NOT NULL AUTO_INCREMENT,
  `user_username` varchar(10) DEFAULT NULL,
  `user_password` varchar(38) DEFAULT NULL,
  `user_fullname` varchar(50) DEFAULT NULL,
  `user_avatar` varchar(255) DEFAULT 'no-photo.jpg',
  `user_status` enum('n','y') DEFAULT 'y',
  `user_level` enum('3','2','1','0') DEFAULT '2',
  `user_created` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `tb_user` (`user_id`, `user_username`, `user_password`, `user_fullname`, `user_avatar`, `user_status`, `user_level`, `user_created`) VALUES ('1', 'andry', '$AS$588b4d6f0f949049ad9a35c4727bf7f3==', 'Andry Priatna', '1481092290_andry.jpg', 'y', '0', '2016-09-05 06:14:12');
INSERT INTO `tb_user` (`user_id`, `user_username`, `user_password`, `user_fullname`, `user_avatar`, `user_status`, `user_level`, `user_created`) VALUES ('2', 'admin', '$AS$82a4cbb74d9dc8fc1eb95a46e71b2a10==', 'Administrator', '1473092024_admin.png', 'y', '2', '0000-00-00 00:00:00');
INSERT INTO `tb_user` (`user_id`, `user_username`, `user_password`, `user_fullname`, `user_avatar`, `user_status`, `user_level`, `user_created`) VALUES ('3', 'owner', '$AS$9625b1f0036195045911e4badc0286dc==', 'Owner', '1473091920_owner.png', 'y', '1', '2016-09-05 10:17:42');
INSERT INTO `tb_user` (`user_id`, `user_username`, `user_password`, `user_fullname`, `user_avatar`, `user_status`, `user_level`, `user_created`) VALUES ('5', 'finance', '$AS$6d10a12b63a7dd917141e1b77ff7fa74==', 'Finance', '1473094761_finance.png', 'y', '3', '2016-09-05 23:59:21');


#
# TABLE STRUCTURE FOR: tb_validasi_pajak
#

DROP TABLE IF EXISTS `tb_validasi_pajak`;

CREATE TABLE `tb_validasi_pajak` (
  `vp_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `booking_id` bigint(20) DEFAULT NULL,
  `vp_status` enum('n','p','y') DEFAULT 'n',
  `vp_date` date DEFAULT '0000-00-00',
  PRIMARY KEY (`vp_id`),
  KEY `vp_bookingid_fk` (`booking_id`),
  CONSTRAINT `vp_bookingid_fk` FOREIGN KEY (`booking_id`) REFERENCES `tb_booking` (`booking_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tb_wawancara
#

DROP TABLE IF EXISTS `tb_wawancara`;

CREATE TABLE `tb_wawancara` (
  `wawancara_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `wawancara_no` varchar(20) DEFAULT NULL,
  `wawancara_tanggal` date DEFAULT '0000-00-00',
  `rumah_id` bigint(20) DEFAULT NULL,
  `booking_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`wawancara_id`),
  KEY `wawancara_rumahid_fk` (`rumah_id`),
  KEY `wawancara_bookingid_fk` (`booking_id`),
  CONSTRAINT `wawancara_bookingid_fk` FOREIGN KEY (`booking_id`) REFERENCES `tb_booking` (`booking_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `wawancara_rumahid_fk` FOREIGN KEY (`rumah_id`) REFERENCES `tb_rumah` (`rumah_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

INSERT INTO `tb_wawancara` (`wawancara_id`, `wawancara_no`, `wawancara_tanggal`, `rumah_id`, `booking_id`) VALUES ('1', '01/RK-PW/VI/2017', '2017-03-15', '1', '20');
INSERT INTO `tb_wawancara` (`wawancara_id`, `wawancara_no`, `wawancara_tanggal`, `rumah_id`, `booking_id`) VALUES ('2', '02/RK-PW/VI/2017', '0000-00-00', '1', '36');
INSERT INTO `tb_wawancara` (`wawancara_id`, `wawancara_no`, `wawancara_tanggal`, `rumah_id`, `booking_id`) VALUES ('3', '03/RK-PW/VI/2017', '0000-00-00', '1', '43');
INSERT INTO `tb_wawancara` (`wawancara_id`, `wawancara_no`, `wawancara_tanggal`, `rumah_id`, `booking_id`) VALUES ('4', '04/RK-PW/VI/2017', '0000-00-00', '2', '19');
INSERT INTO `tb_wawancara` (`wawancara_id`, `wawancara_no`, `wawancara_tanggal`, `rumah_id`, `booking_id`) VALUES ('5', '05/RK-PW/VI/2017', '0000-00-00', '2', '2');
INSERT INTO `tb_wawancara` (`wawancara_id`, `wawancara_no`, `wawancara_tanggal`, `rumah_id`, `booking_id`) VALUES ('6', '06/RK-PW/VI/2017', '0000-00-00', '2', '40');
INSERT INTO `tb_wawancara` (`wawancara_id`, `wawancara_no`, `wawancara_tanggal`, `rumah_id`, `booking_id`) VALUES ('7', '07/RK-PW/VI/2017', '0000-00-00', '2', '3');
INSERT INTO `tb_wawancara` (`wawancara_id`, `wawancara_no`, `wawancara_tanggal`, `rumah_id`, `booking_id`) VALUES ('8', '08/RK-PW/VI/2017', '0000-00-00', '2', '4');
INSERT INTO `tb_wawancara` (`wawancara_id`, `wawancara_no`, `wawancara_tanggal`, `rumah_id`, `booking_id`) VALUES ('9', '09/RK-PW/VI/2017', '0000-00-00', '2', '11');
INSERT INTO `tb_wawancara` (`wawancara_id`, `wawancara_no`, `wawancara_tanggal`, `rumah_id`, `booking_id`) VALUES ('10', '10/RK-PW/VI/2017', '0000-00-00', '2', '5');
INSERT INTO `tb_wawancara` (`wawancara_id`, `wawancara_no`, `wawancara_tanggal`, `rumah_id`, `booking_id`) VALUES ('11', '11/RK-PW/VI/2017', '0000-00-00', '2', '6');
INSERT INTO `tb_wawancara` (`wawancara_id`, `wawancara_no`, `wawancara_tanggal`, `rumah_id`, `booking_id`) VALUES ('12', '12/RK-PW/VI/2017', '0000-00-00', '2', '14');
INSERT INTO `tb_wawancara` (`wawancara_id`, `wawancara_no`, `wawancara_tanggal`, `rumah_id`, `booking_id`) VALUES ('13', '13/RK-PW/VI/2017', '0000-00-00', '2', '12');
INSERT INTO `tb_wawancara` (`wawancara_id`, `wawancara_no`, `wawancara_tanggal`, `rumah_id`, `booking_id`) VALUES ('14', '14/RK-PW/VI/2017', '0000-00-00', '2', '32');
INSERT INTO `tb_wawancara` (`wawancara_id`, `wawancara_no`, `wawancara_tanggal`, `rumah_id`, `booking_id`) VALUES ('15', '15/RK-PW/VI/2017', '0000-00-00', '2', '8');


#
# TABLE STRUCTURE FOR: uraian_penerimaan
#

DROP TABLE IF EXISTS `uraian_penerimaan`;

CREATE TABLE `uraian_penerimaan` (
  `up_id` varchar(100) NOT NULL,
  `up_nama` varchar(100) DEFAULT NULL,
  `pkategori_id` bigint(20) DEFAULT NULL,
  `order` int(50) DEFAULT NULL,
  PRIMARY KEY (`up_id`),
  UNIQUE KEY `up_id` (`up_id`),
  KEY `up_pkategoriid_fk` (`pkategori_id`),
  CONSTRAINT `up_pkategoriid_fk` FOREIGN KEY (`pkategori_id`) REFERENCES `penerimaan_kategori` (`pkategori_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `uraian_penerimaan` (`up_id`, `up_nama`, `pkategori_id`, `order`) VALUES ('Bantuan Uang Muka', 'Bantuan Uang Muka', '2', '6');
INSERT INTO `uraian_penerimaan` (`up_id`, `up_nama`, `pkategori_id`, `order`) VALUES ('Pembayaran ke 1', 'Pembayaran ke 1', '3', '1');
INSERT INTO `uraian_penerimaan` (`up_id`, `up_nama`, `pkategori_id`, `order`) VALUES ('Pembayaran ke 10', 'Pembayaran ke 10', '3', '10');
INSERT INTO `uraian_penerimaan` (`up_id`, `up_nama`, `pkategori_id`, `order`) VALUES ('Pembayaran ke 2', 'Pembayaran ke 2', '3', '2');
INSERT INTO `uraian_penerimaan` (`up_id`, `up_nama`, `pkategori_id`, `order`) VALUES ('Pembayaran ke 3', 'Pembayaran ke 3', '3', '3');
INSERT INTO `uraian_penerimaan` (`up_id`, `up_nama`, `pkategori_id`, `order`) VALUES ('Pembayaran ke 4', 'Pembayaran ke 4', '3', '4');
INSERT INTO `uraian_penerimaan` (`up_id`, `up_nama`, `pkategori_id`, `order`) VALUES ('Pembayaran ke 5', 'Pembayaran ke 5', '3', '5');
INSERT INTO `uraian_penerimaan` (`up_id`, `up_nama`, `pkategori_id`, `order`) VALUES ('Pembayaran ke 6', 'Pembayaran ke 6', '3', '6');
INSERT INTO `uraian_penerimaan` (`up_id`, `up_nama`, `pkategori_id`, `order`) VALUES ('Pembayaran ke 7', 'Pembayaran ke 7', '3', '7');
INSERT INTO `uraian_penerimaan` (`up_id`, `up_nama`, `pkategori_id`, `order`) VALUES ('Pembayaran ke 8', 'Pembayaran ke 8', '3', '8');
INSERT INTO `uraian_penerimaan` (`up_id`, `up_nama`, `pkategori_id`, `order`) VALUES ('Pembayaran ke 9', 'Pembayaran ke 9', '3', '9');
INSERT INTO `uraian_penerimaan` (`up_id`, `up_nama`, `pkategori_id`, `order`) VALUES ('Pencairan IMB', 'Pencairan IMB', '2', '1');
INSERT INTO `uraian_penerimaan` (`up_id`, `up_nama`, `pkategori_id`, `order`) VALUES ('Pencairan Induk', 'Pencairan Induk', '2', '2');
INSERT INTO `uraian_penerimaan` (`up_id`, `up_nama`, `pkategori_id`, `order`) VALUES ('Pencairan Jalan', 'Pencairan Jalan', '2', '3');
INSERT INTO `uraian_penerimaan` (`up_id`, `up_nama`, `pkategori_id`, `order`) VALUES ('Pencairan Listrik', 'Pencairan Listrik', '2', '4');
INSERT INTO `uraian_penerimaan` (`up_id`, `up_nama`, `pkategori_id`, `order`) VALUES ('Pencairan Sertifikat', 'Pencairan Sertifikat', '2', '5');


